"""
LibraryOS - Standalone Desktop Launcher
Creates a native Windows application using WebView2
Build with: pyinstaller --onefile --windowed --name LibraryOS --icon=icon.ico launcher.py
"""

import webview
import os
import sys
from pathlib import Path

def get_app_path():
    """Get the application directory path"""
    if getattr(sys, 'frozen', False):
        # Running as compiled exe
        return os.path.dirname(sys.executable)
    else:
        # Running as script
        return os.path.dirname(os.path.abspath(__file__))

def get_html_path():
    """Get the path to the main HTML file"""
    app_path = get_app_path()
    html_path = os.path.join(app_path, 'dist', 'index.html')
    
    if not os.path.exists(html_path):
        print(f"ERROR: Could not find {html_path}")
        print("\nPlease ensure:")
        print("1. You have run 'npm run build'")
        print("2. The 'dist' folder is in the same directory as this exe")
        input("\nPress Enter to exit...")
        sys.exit(1)
    
    return html_path

def main():
    """Main application entry point"""
    try:
        html_path = get_html_path()
        
        # Convert to file URL
        file_url = 'file:///' + html_path.replace('\\', '/')
        
        # Create the application window
        window = webview.create_window(
            title='LibraryOS - Library Management System',
            url=file_url,
            width=1400,
            height=900,
            min_size=(800, 600),
            resizable=True,
            fullscreen=False,
            background_color='#FFFFFF',
            text_select=True
        )
        
        # Start the application
        webview.start(debug=False, gui='edgechromium')
        
    except Exception as e:
        print(f"ERROR: Failed to start application")
        print(f"Details: {str(e)}")
        input("\nPress Enter to exit...")
        sys.exit(1)

if __name__ == '__main__':
    main()
