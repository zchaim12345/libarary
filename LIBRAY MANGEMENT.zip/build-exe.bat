@echo off
title LibraryOS - Auto EXE Builder
color 0A

echo.
echo ========================================
echo   LibraryOS - Automatic EXE Builder
echo ========================================
echo.

REM Step 1: Install dependencies
echo [1/5] Installing dependencies...
call npm install
if errorlevel 1 (
    echo ERROR: npm install failed!
    pause
    exit /b 1
)

REM Step 2: Build the web application
echo.
echo [2/5] Building web application...
call npm run build
if errorlevel 1 (
    echo ERROR: Build failed!
    pause
    exit /b 1
)

REM Step 3: Check if Python is installed
echo.
echo [3/5] Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo WARNING: Python not found!
    echo.
    echo Please install Python from: https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during installation.
    echo.
    echo Alternative: Use BUILD-EXE.bat and select option 2 (HTA) or 3 (Portable Chrome)
    echo.
    pause
    exit /b 1
)

REM Step 4: Install Python dependencies
echo.
echo [4/5] Installing Python dependencies...
pip install pywebview pyinstaller pyinstaller-hooks-contrib
if errorlevel 1 (
    echo ERROR: Failed to install Python packages!
    pause
    exit /b 1
)

REM Step 5: Build the EXE
echo.
echo [5/5] Building standalone EXE...
pyinstaller --noconfirm --onefile --windowed --name "LibraryOS" ^
    --add-data "dist;dist" ^
    --hidden-import "clr" ^
    launcher.py

if errorlevel 1 (
    echo ERROR: PyInstaller failed!
    pause
    exit /b 1
)

REM Step 6: Organize output
echo.
echo [6/6] Organizing files...
if not exist "Release" mkdir Release
if not exist "Release\LibraryOS" mkdir Release\LibraryOS

xcopy /E /I /Y dist Release\LibraryOS\dist
copy dist\LibraryOS.exe Release\LibraryOS\LibraryOS.exe

echo.
echo ========================================
echo   BUILD COMPLETE!
echo ========================================
echo.
echo Your standalone application is ready in:
echo   Release\LibraryOS\
echo.
echo Files:
echo   - LibraryOS.exe (Standalone application)
echo   - dist\ (Application files)
echo.
echo To distribute:
echo   Zip the entire "LibraryOS" folder and share it!
echo.
echo Users can run LibraryOS.exe without installing anything!
echo.
pause
