import { createBrowserRouter } from 'react-router';
import { Layout } from './components/Layout';
import { Dashboard } from './pages/Dashboard';
import { Books } from './pages/Books';
import { Members } from './pages/Members';
import { Transactions } from './pages/Transactions';
import { Reports } from './pages/Reports';
import { Settings } from './pages/Settings';
import { Shabbos } from './pages/Shabbos';
import { UserProfiles } from './pages/UserProfiles';
import { Admin } from './pages/Admin';
import { Donations } from './pages/Donations';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <Layout><Dashboard /></Layout>,
  },
  {
    path: '/books',
    element: <Layout><Books /></Layout>,
  },
  {
    path: '/members',
    element: <Layout><Members /></Layout>,
  },
  {
    path: '/transactions',
    element: <Layout><Transactions /></Layout>,
  },
  {
    path: '/shabbos',
    element: <Layout><Shabbos /></Layout>,
  },
  {
    path: '/user-profiles',
    element: <Layout><UserProfiles /></Layout>,
  },
  {
    path: '/reports',
    element: <Layout><Reports /></Layout>,
  },
  {
    path: '/donations',
    element: <Layout><Donations /></Layout>,
  },
  {
    path: '/admin',
    element: <Layout><Admin /></Layout>,
  },
  {
    path: '/settings',
    element: <Layout><Settings /></Layout>,
  },
]);