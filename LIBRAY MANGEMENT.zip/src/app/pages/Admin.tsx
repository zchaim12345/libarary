import { useEffect, useState } from 'react';
import { Shield, Users, AlertTriangle, Activity, Settings as SettingsIcon, Key, Ban, CheckCircle, Clock } from 'lucide-react';
import { Member, ActivityLog } from '../types';
import { getMembers, updateMember } from '../lib/storage';
import { getAdminSettings, saveAdminSettings, getActivityLog, clearActivityLog, addActivityLog, updateAdminCode } from '../lib/admin';
import { BanMemberDialog } from '../components/BanMemberDialog';
import { toast } from 'sonner';

export function Admin() {
  const [members, setMembers] = useState<Member[]>([]);
  const [activityLog, setActivityLog] = useState<ActivityLog[]>([]);
  const [settings, setSettings] = useState(getAdminSettings());
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [showBanDialog, setShowBanDialog] = useState(false);
  const [showChangeCode, setShowChangeCode] = useState(false);
  const [oldCode, setOldCode] = useState('');
  const [newCode, setNewCode] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setMembers(getMembers());
    setActivityLog(getActivityLog());
    setSettings(getAdminSettings());
  };

  const handleBanMember = (member: Member, banInfo: any) => {
    updateMember(member.id, {
      ...member,
      status: 'banned',
      banInfo,
    });

    addActivityLog({
      action: 'BAN_USER',
      performedBy: 'Admin',
      targetUser: member.name,
      details: `Banned for: ${banInfo.reason}`,
    });

    toast.success(`${member.name} has been banned`);
    loadData();
    setShowBanDialog(false);
    setSelectedMember(null);
  };

  const handleUnbanMember = (member: Member) => {
    if (!confirm(`Unban ${member.name}?`)) return;

    updateMember(member.id, {
      ...member,
      status: 'active',
      banInfo: undefined,
    });

    addActivityLog({
      action: 'UNBAN_USER',
      performedBy: 'Admin',
      targetUser: member.name,
      details: 'User unbanned',
    });

    toast.success(`${member.name} has been unbanned`);
    loadData();
  };

  const handleSettingsUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    saveAdminSettings(settings);
    
    addActivityLog({
      action: 'UPDATE_SETTINGS',
      performedBy: 'Admin',
      details: 'System settings updated',
    });

    toast.success('Settings updated successfully');
  };

  const handleChangeAdminCode = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (updateAdminCode(oldCode, newCode)) {
      addActivityLog({
        action: 'CHANGE_ADMIN_CODE',
        performedBy: 'Admin',
        details: 'Admin code changed',
      });

      toast.success('Admin code changed successfully');
      setShowChangeCode(false);
      setOldCode('');
      setNewCode('');
      loadData();
    } else {
      toast.error('Current code is incorrect');
    }
  };

  const handleClearLog = () => {
    if (confirm('Clear entire activity log? This cannot be undone.')) {
      clearActivityLog();
      addActivityLog({
        action: 'CLEAR_LOG',
        performedBy: 'Admin',
        details: 'Activity log cleared',
      });
      loadData();
      toast.success('Activity log cleared');
    }
  };

  const bannedMembers = members.filter(m => m.status === 'banned');
  const activeMembers = members.filter(m => m.status === 'active');
  const suspendedMembers = members.filter(m => m.status === 'suspended');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900 flex items-center gap-2">
            <Shield className="w-8 h-8 text-blue-600" />
            Admin Control Panel
          </h1>
          <p className="text-gray-600 mt-1">Manage users, bans, and system settings</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Active Users</p>
              <p className="text-3xl font-semibold text-green-600 mt-2">{activeMembers.length}</p>
            </div>
            <div className="bg-green-100 p-3 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Banned Users</p>
              <p className="text-3xl font-semibold text-red-600 mt-2">{bannedMembers.length}</p>
            </div>
            <div className="bg-red-100 p-3 rounded-lg">
              <Ban className="w-6 h-6 text-red-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Suspended</p>
              <p className="text-3xl font-semibold text-orange-600 mt-2">{suspendedMembers.length}</p>
            </div>
            <div className="bg-orange-100 p-3 rounded-lg">
              <Clock className="w-6 h-6 text-orange-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Users</p>
              <p className="text-3xl font-semibold text-blue-600 mt-2">{members.length}</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>
      </div>

      {/* User Management */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200 p-4">
          <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            User Management
          </h2>
        </div>
        
        <div className="p-6">
          <div className="space-y-3">
            {members.map(member => (
              <div key={member.id} className={`border rounded-lg p-4 ${member.status === 'banned' ? 'border-red-300 bg-red-50' : 'border-gray-200'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <h3 className="font-semibold text-gray-900">{member.name}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        member.status === 'active' ? 'bg-green-100 text-green-700' :
                        member.status === 'banned' ? 'bg-red-100 text-red-700' :
                        member.status === 'suspended' ? 'bg-orange-100 text-orange-700' :
                        'bg-gray-100 text-gray-700'
                      }`}>
                        {member.status.toUpperCase()}
                      </span>
                    </div>
                    <div className="mt-1 flex gap-4 text-sm text-gray-600">
                      <span>{member.membershipId}</span>
                      <span>{member.email}</span>
                      <span>{member.phone}</span>
                    </div>
                    {member.banInfo && (
                      <div className="mt-2 text-sm text-red-700">
                        <p><strong>Ban Reason:</strong> {member.banInfo.reason}</p>
                        {member.banInfo.notes && <p><strong>Notes:</strong> {member.banInfo.notes}</p>}
                        <p><strong>Banned:</strong> {new Date(member.banInfo.bannedDate).toLocaleDateString()}</p>
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2">
                    {member.status === 'banned' ? (
                      <button
                        onClick={() => handleUnbanMember(member)}
                        className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
                      >
                        <CheckCircle className="w-4 h-4" />
                        Unban
                      </button>
                    ) : (
                      <button
                        onClick={() => {
                          setSelectedMember(member);
                          setShowBanDialog(true);
                        }}
                        className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors flex items-center gap-2"
                      >
                        <Ban className="w-4 h-4" />
                        Ban
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* System Settings */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200 p-4">
          <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <SettingsIcon className="w-5 h-5 text-blue-600" />
            System Settings
          </h2>
        </div>
        
        <form onSubmit={handleSettingsUpdate} className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Library Name
              </label>
              <input
                type="text"
                value={settings.libraryName}
                onChange={(e) => setSettings({...settings, libraryName: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Default Loan Period (days)
              </label>
              <input
                type="number"
                min="1"
                max="90"
                value={settings.defaultLoanPeriod}
                onChange={(e) => setSettings({...settings, defaultLoanPeriod: parseInt(e.target.value)})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Late Fee Per Day ($)
              </label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={settings.lateFeePerDay}
                onChange={(e) => setSettings({...settings, lateFeePerDay: parseFloat(e.target.value)})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Max Books Per Member
              </label>
              <input
                type="number"
                min="1"
                max="20"
                value={settings.maxBooksPerMember}
                onChange={(e) => setSettings({...settings, maxBooksPerMember: parseInt(e.target.value)})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="guestCheckout"
              checked={settings.allowGuestCheckout}
              onChange={(e) => setSettings({...settings, allowGuestCheckout: e.target.checked})}
              className="w-4 h-4 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
            />
            <label htmlFor="guestCheckout" className="text-sm text-gray-700">
              Allow guest checkouts
            </label>
          </div>

          <button
            type="submit"
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            Save Settings
          </button>
        </form>
      </div>

      {/* Admin Code */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200 p-4">
          <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <Key className="w-5 h-5 text-blue-600" />
            Admin Code
          </h2>
        </div>
        
        <div className="p-6">
          {!showChangeCode ? (
            <button
              onClick={() => setShowChangeCode(true)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Change Admin Code
            </button>
          ) : (
            <form onSubmit={handleChangeAdminCode} className="space-y-4 max-w-md">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Current Code
                </label>
                <input
                  type="password"
                  required
                  value={oldCode}
                  onChange={(e) => setOldCode(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  New Code
                </label>
                <input
                  type="password"
                  required
                  minLength={4}
                  value={newCode}
                  onChange={(e) => setNewCode(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Update Code
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setShowChangeCode(false);
                    setOldCode('');
                    setNewCode('');
                  }}
                  className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* Activity Log */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200 p-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <Activity className="w-5 h-5 text-blue-600" />
            Activity Log
          </h2>
          <button
            onClick={handleClearLog}
            className="text-sm text-red-600 hover:text-red-700"
          >
            Clear Log
          </button>
        </div>
        
        <div className="p-6 max-h-96 overflow-y-auto">
          {activityLog.length > 0 ? (
            <div className="space-y-2">
              {activityLog.slice(0, 50).map(log => (
                <div key={log.id} className="text-sm bg-gray-50 rounded p-3">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{log.action.replace(/_/g, ' ')}</p>
                      <p className="text-gray-600 mt-1">{log.details}</p>
                      {log.targetUser && (
                        <p className="text-gray-500 text-xs mt-1">User: {log.targetUser}</p>
                      )}
                    </div>
                    <div className="text-right ml-4">
                      <p className="text-xs text-gray-500">{new Date(log.timestamp).toLocaleString()}</p>
                      <p className="text-xs text-gray-400">{log.performedBy}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500 py-8">No activity logged yet</p>
          )}
        </div>
      </div>

      {showBanDialog && selectedMember && (
        <BanMemberDialog
          member={selectedMember}
          onBan={(banInfo) => handleBanMember(selectedMember, banInfo)}
          onClose={() => {
            setShowBanDialog(false);
            setSelectedMember(null);
          }}
        />
      )}
    </div>
  );
}
