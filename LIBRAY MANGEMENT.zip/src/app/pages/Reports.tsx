import { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, BookOpen, Users, Clock } from 'lucide-react';
import { getBooks, getMembers, getTransactions } from '../lib/storage';

export function Reports() {
  const [stats, setStats] = useState({
    categoryData: [] as Array<{ name: string; count: number }>,
    borrowingTrends: [] as Array<{ month: string; borrowed: number; returned: number }>,
    topBooks: [] as Array<{ title: string; timesB: number }>,
    memberActivity: [] as Array<{ status: string; count: number }>,
  });

  useEffect(() => {
    const books = getBooks();
    const members = getMembers();
    const transactions = getTransactions();

    // Category distribution
    const categoryMap = new Map<string, number>();
    books.forEach(book => {
      categoryMap.set(book.category, (categoryMap.get(book.category) || 0) + book.copies);
    });
    const categoryData = Array.from(categoryMap.entries())
      .map(([name, count]) => ({ name, count }))
      .sort((a, b) => b.count - a.count);

    // Book borrowing frequency
    const bookBorrowMap = new Map<string, number>();
    transactions.forEach(t => {
      const book = books.find(b => b.id === t.bookId);
      if (book) {
        bookBorrowMap.set(book.title, (bookBorrowMap.get(book.title) || 0) + 1);
      }
    });
    const topBooks = Array.from(bookBorrowMap.entries())
      .map(([title, timesBorrowed]) => ({ title, timesBorrowed }))
      .sort((a, b) => b.timesBorrowed - a.timesBorrowed)
      .slice(0, 5);

    // Member activity
    const memberActivity = [
      { status: 'Active', count: members.filter(m => m.status === 'active').length },
      { status: 'Inactive', count: members.filter(m => m.status === 'inactive').length },
      { status: 'Suspended', count: members.filter(m => m.status === 'suspended').length },
    ].filter(m => m.count > 0);

    // Borrowing trends (last 6 months)
    const monthlyData = [];
    for (let i = 5; i >= 0; i--) {
      const date = new Date();
      date.setMonth(date.getMonth() - i);
      const month = date.toLocaleString('default', { month: 'short' });
      
      const borrowed = transactions.filter(t => {
        const tDate = new Date(t.checkoutDate);
        return tDate.getMonth() === date.getMonth() && tDate.getFullYear() === date.getFullYear();
      }).length;

      const returned = transactions.filter(t => {
        if (!t.returnDate) return false;
        const tDate = new Date(t.returnDate);
        return tDate.getMonth() === date.getMonth() && tDate.getFullYear() === date.getFullYear();
      }).length;

      monthlyData.push({ month, borrowed, returned });
    }

    setStats({
      categoryData,
      borrowingTrends: monthlyData,
      topBooks,
      memberActivity,
    });
  }, []);

  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Reports & Analytics</h1>
        <p className="text-gray-600 mt-1">Insights and statistics about your library</p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg shadow-sm p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-blue-100 text-sm">Total Books</p>
              <p className="text-3xl font-semibold mt-1">
                {getBooks().reduce((sum, b) => sum + b.copies, 0)}
              </p>
            </div>
            <BookOpen className="w-10 h-10 text-blue-200" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-lg shadow-sm p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-100 text-sm">Total Members</p>
              <p className="text-3xl font-semibold mt-1">{getMembers().length}</p>
            </div>
            <Users className="w-10 h-10 text-green-200" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg shadow-sm p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-purple-100 text-sm">Currently Borrowed</p>
              <p className="text-3xl font-semibold mt-1">
                {getTransactions().filter(t => t.status === 'borrowed').length}
              </p>
            </div>
            <Clock className="w-10 h-10 text-purple-200" />
          </div>
        </div>

        <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg shadow-sm p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-orange-100 text-sm">Total Transactions</p>
              <p className="text-3xl font-semibold mt-1">{getTransactions().length}</p>
            </div>
            <TrendingUp className="w-10 h-10 text-orange-200" />
          </div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Category Distribution */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Books by Category</h2>
          {stats.categoryData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={stats.categoryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                >
                  {stats.categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-center text-gray-500 py-12">No data available</p>
          )}
        </div>

        {/* Member Activity */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Member Status Distribution</h2>
          {stats.memberActivity.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={stats.memberActivity}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="status" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="count" fill="#3B82F6" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-center text-gray-500 py-12">No data available</p>
          )}
        </div>

        {/* Borrowing Trends */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 lg:col-span-2">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Borrowing Trends (Last 6 Months)</h2>
          {stats.borrowingTrends.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={stats.borrowingTrends}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="borrowed" fill="#3B82F6" name="Borrowed" />
                <Bar dataKey="returned" fill="#10B981" name="Returned" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-center text-gray-500 py-12">No data available</p>
          )}
        </div>

        {/* Top Borrowed Books */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 lg:col-span-2">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Most Borrowed Books</h2>
          {stats.topBooks.length > 0 ? (
            <div className="space-y-3">
              {stats.topBooks.map((book, index) => (
                <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <div className="bg-blue-100 text-blue-700 font-semibold w-8 h-8 rounded-full flex items-center justify-center text-sm">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{book.title}</p>
                  </div>
                  <div className="text-sm text-gray-600">
                    <span className="font-medium">{book.timesBorrowed}</span> times borrowed
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-500 py-12">No borrowing data available</p>
          )}
        </div>
      </div>
    </div>
  );
}
