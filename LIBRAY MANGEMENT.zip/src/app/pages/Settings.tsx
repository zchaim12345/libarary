import { useState } from 'react';
import { Download, Upload, Trash2, Database, FileDown, FileText, Users as UsersIcon, BookOpen as BookIcon, ArrowLeftRight } from 'lucide-react';
import { downloadData, importData, clearAllData, exportBooksToCSV, exportMembersToCSV, exportTransactionsToCSV } from '../lib/export';
import { getBooks, getMembers, getTransactions } from '../lib/storage';

export function Settings() {
  const [importing, setImporting] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const stats = {
    books: getBooks().length,
    members: getMembers().length,
    transactions: getTransactions().length,
  };

  const handleExport = () => {
    try {
      downloadData();
      setMessage({ type: 'success', text: 'Data exported successfully!' });
      setTimeout(() => setMessage(null), 3000);
    } catch (error) {
      setMessage({ type: 'error', text: 'Failed to export data' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    const reader = new FileReader();
    
    reader.onload = (e) => {
      const content = e.target?.result as string;
      const result = importData(content);
      
      setMessage({ type: result.success ? 'success' : 'error', text: result.message });
      setImporting(false);
      
      if (result.success) {
        setTimeout(() => window.location.reload(), 2000);
      } else {
        setTimeout(() => setMessage(null), 3000);
      }
    };

    reader.onerror = () => {
      setMessage({ type: 'error', text: 'Failed to read file' });
      setImporting(false);
      setTimeout(() => setMessage(null), 3000);
    };

    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Settings & Data Management</h1>
        <p className="text-gray-600 mt-1">Manage your library data and system settings</p>
      </div>

      {message && (
        <div className={`p-4 rounded-lg ${message.type === 'success' ? 'bg-green-50 text-green-800 border border-green-200' : 'bg-red-50 text-red-800 border border-red-200'}`}>
          {message.text}
        </div>
      )}

      {/* Database Stats */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <Database className="w-5 h-5 text-blue-600" />
          Database Statistics
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <BookIcon className="w-8 h-8 text-blue-600" />
              <div>
                <p className="text-2xl font-semibold text-gray-900">{stats.books}</p>
                <p className="text-sm text-gray-600">Books</p>
              </div>
            </div>
          </div>
          <div className="bg-green-50 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <UsersIcon className="w-8 h-8 text-green-600" />
              <div>
                <p className="text-2xl font-semibold text-gray-900">{stats.members}</p>
                <p className="text-sm text-gray-600">Members</p>
              </div>
            </div>
          </div>
          <div className="bg-purple-50 rounded-lg p-4">
            <div className="flex items-center gap-3">
              <ArrowLeftRight className="w-8 h-8 text-purple-600" />
              <div>
                <p className="text-2xl font-semibold text-gray-900">{stats.transactions}</p>
                <p className="text-sm text-gray-600">Transactions</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Backup & Restore */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Backup & Restore</h2>
        <div className="space-y-4">
          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-start gap-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Download className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium text-gray-900">Export All Data</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Download a complete backup of your library data as a JSON file. This includes all books, members, and transactions.
                </p>
                <button
                  onClick={handleExport}
                  className="mt-3 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  Export Data (JSON)
                </button>
              </div>
            </div>
          </div>

          <div className="border border-gray-200 rounded-lg p-4">
            <div className="flex items-start gap-4">
              <div className="bg-green-100 p-3 rounded-lg">
                <Upload className="w-6 h-6 text-green-600" />
              </div>
              <div className="flex-1">
                <h3 className="font-medium text-gray-900">Import Data</h3>
                <p className="text-sm text-gray-600 mt-1">
                  Restore your library data from a previously exported JSON file. This will replace all current data.
                </p>
                <label className="mt-3 inline-block">
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImport}
                    disabled={importing}
                    className="hidden"
                  />
                  <span className={`px-4 py-2 ${importing ? 'bg-gray-400' : 'bg-green-600 hover:bg-green-700'} text-white rounded-lg transition-colors cursor-pointer inline-flex items-center gap-2`}>
                    <Upload className="w-4 h-4" />
                    {importing ? 'Importing...' : 'Import Data (JSON)'}
                  </span>
                </label>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Export Reports */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <FileDown className="w-5 h-5 text-purple-600" />
          Export Reports (CSV)
        </h2>
        <p className="text-sm text-gray-600 mb-4">
          Export specific data to CSV format for use in Excel or other spreadsheet applications.
        </p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <button
            onClick={exportBooksToCSV}
            className="p-4 border-2 border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all text-left"
          >
            <BookIcon className="w-6 h-6 text-blue-600 mb-2" />
            <h3 className="font-medium text-gray-900">Books Report</h3>
            <p className="text-sm text-gray-600 mt-1">Export all books data</p>
          </button>

          <button
            onClick={exportMembersToCSV}
            className="p-4 border-2 border-gray-200 rounded-lg hover:border-green-500 hover:bg-green-50 transition-all text-left"
          >
            <UsersIcon className="w-6 h-6 text-green-600 mb-2" />
            <h3 className="font-medium text-gray-900">Members Report</h3>
            <p className="text-sm text-gray-600 mt-1">Export all members data</p>
          </button>

          <button
            onClick={exportTransactionsToCSV}
            className="p-4 border-2 border-gray-200 rounded-lg hover:border-purple-500 hover:bg-purple-50 transition-all text-left"
          >
            <ArrowLeftRight className="w-6 h-6 text-purple-600 mb-2" />
            <h3 className="font-medium text-gray-900">Transactions Report</h3>
            <p className="text-sm text-gray-600 mt-1">Export all transactions</p>
          </button>
        </div>
      </div>

      {/* System Information */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <FileText className="w-5 h-5 text-gray-600" />
          System Information
        </h2>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between py-2 border-b border-gray-100">
            <span className="text-gray-600">Application Version</span>
            <span className="font-medium text-gray-900">1.0.0</span>
          </div>
          <div className="flex justify-between py-2 border-b border-gray-100">
            <span className="text-gray-600">Storage Type</span>
            <span className="font-medium text-gray-900">Local Storage (Offline)</span>
          </div>
          <div className="flex justify-between py-2 border-b border-gray-100">
            <span className="text-gray-600">Data Location</span>
            <span className="font-medium text-gray-900">Browser Local Storage</span>
          </div>
          <div className="flex justify-between py-2">
            <span className="text-gray-600">Last Updated</span>
            <span className="font-medium text-gray-900">{new Date().toLocaleDateString()}</span>
          </div>
        </div>
      </div>

      {/* Danger Zone */}
      <div className="bg-red-50 border border-red-200 rounded-lg p-6">
        <h2 className="text-lg font-semibold text-red-900 mb-4 flex items-center gap-2">
          <Trash2 className="w-5 h-5" />
          Danger Zone
        </h2>
        <div className="border border-red-200 bg-white rounded-lg p-4">
          <h3 className="font-medium text-gray-900">Clear All Data</h3>
          <p className="text-sm text-gray-600 mt-1 mb-3">
            Permanently delete all books, members, and transactions. This action cannot be undone.
          </p>
          <button
            onClick={clearAllData}
            className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors flex items-center gap-2"
          >
            <Trash2 className="w-4 h-4" />
            Clear All Data
          </button>
        </div>
      </div>

      {/* Instructions for Creating EXE */}
      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border border-blue-200 rounded-lg p-6">
        <h2 className="text-lg font-semibold text-blue-900 mb-4">📦 Creating Executable File</h2>
        <div className="space-y-3 text-sm text-gray-700">
          <p>
            <strong>To create a standalone Windows executable (.exe):</strong>
          </p>
          <ol className="list-decimal list-inside space-y-2 ml-2">
            <li>Build the application: <code className="bg-white px-2 py-1 rounded border border-gray-300">npm run build</code></li>
            <li>Install Electron or similar tool: <code className="bg-white px-2 py-1 rounded border border-gray-300">npm install -g electron-packager</code></li>
            <li>Package as executable for your platform</li>
          </ol>
          <p className="mt-4">
            <strong>Alternative (Simpler):</strong> Use Tauri or NW.js to package this web app as a desktop application.
          </p>
          <div className="mt-4 p-3 bg-white rounded border border-blue-200">
            <p className="font-medium text-blue-900 mb-1">💡 Recommended Tools:</p>
            <ul className="list-disc list-inside text-gray-700 space-y-1">
              <li><strong>Tauri</strong> - Lightweight, Rust-based (recommended)</li>
              <li><strong>Electron</strong> - Popular, full-featured</li>
              <li><strong>NW.js</strong> - Easy to use, Node.js-based</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
