import { useEffect, useState } from 'react';
import { BookOpen, Calendar, DollarSign, Clock, CheckCircle, AlertCircle, Upload } from 'lucide-react';
import { Book, Transaction, Member, SHABBOS_RULES } from '../types';
import { getBooks, getMembers, getTransactions, addTransaction, updateTransaction, updateBook } from '../lib/storage';
import { ShabbosCheckoutDialog } from '../components/ShabbosCheckoutDialog';
import { FormUploadDialog } from '../components/FormUploadDialog';
import { calculateDepositRefund, formatTimeRemaining, isDepositRequired, isShabbosCheckoutAllowed, getDayName } from '../lib/shabbos-logic';
import { toast } from 'sonner';

export function Shabbos() {
  const [books, setBooks] = useState<Book[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [shabbosBooks, setShabbosBooks] = useState<Book[]>([]);
  const [activeCheckouts, setActiveCheckouts] = useState<Transaction[]>([]);
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [showFormUpload, setShowFormUpload] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const allBooks = getBooks();
    const allMembers = getMembers();
    const allTransactions = getTransactions();

    setBooks(allBooks);
    setMembers(allMembers);
    setTransactions(allTransactions);

    // Filter Shabbos books
    const shabbosOnly = allBooks.filter(b => b.shabbosCategory && b.shabbosCategory !== 'regular');
    setShabbosBooks(shabbosOnly);

    // Filter active Shabbos checkouts
    const active = allTransactions.filter(t => t.isShabbosCheckout && t.status !== 'returned');
    setActiveCheckouts(active);
  };

  const handleCheckout = (book: Book, memberId: string, paymentMethod: 'cash' | 'credit-card' | 'none', creditCardId?: string) => {
    const member = members.find(m => m.id === memberId);
    if (!member) return;

    const now = new Date();
    const monday = new Date(now);
    monday.setDate(now.getDate() + ((1 + 7 - now.getDay()) % 7 || 7)); // Next Monday
    monday.setHours(13, 30, 0, 0);

    const depositAmount = book.depositAmount || SHABBOS_RULES[book.shabbosCategory!].depositRange[0];
    const needsDeposit = isDepositRequired();

    const transaction: Transaction = {
      id: Date.now().toString(),
      bookId: book.id,
      memberId: member.id,
      checkoutDate: now.toISOString(),
      dueDate: monday.toISOString(),
      status: 'borrowed',
      isShabbosCheckout: true,
      depositAmount: needsDeposit ? depositAmount : 0,
      depositPaid: needsDeposit ? depositAmount : 0,
      paymentMethod: paymentMethod === 'none' ? undefined : paymentMethod,
      creditCardId,
      returnDeadline: monday.toISOString(),
    };

    addTransaction(transaction);
    updateBook(book.id, {
      ...book,
      availableCopies: book.availableCopies - 1,
    });

    if (needsDeposit) {
      const methodText = paymentMethod === 'cash' ? 'Cash' : 'Credit Card';
      toast.success(`Book checked out! ${methodText} deposit: $${depositAmount.toFixed(2)}`);
      
      if (paymentMethod === 'cash') {
        toast.info(`💵 Please collect $${depositAmount.toFixed(2)} from ${member.name}`);
      }
    } else {
      toast.success(`Book checked out FREE! No deposit required (${getDayName()})`);
    }

    loadData();
    setSelectedBook(null);
  };

  const handleReturn = (transaction: Transaction) => {
    const book = books.find(b => b.id === transaction.bookId);
    const member = members.find(m => m.id === transaction.memberId);
    if (!book || !member) return;

    const now = new Date();
    const refundInfo = calculateDepositRefund(
      transaction.depositPaid || 0,
      transaction.checkoutDate,
      now.toISOString()
    );

    updateTransaction(transaction.id, {
      ...transaction,
      returnDate: now.toISOString(),
      status: 'returned',
      depositRefunded: refundInfo.refund,
      depositReduction: refundInfo.reduction,
    });

    updateBook(book.id, {
      ...book,
      availableCopies: book.availableCopies + 1,
    });

    toast.success(`Book returned! Refund: $${refundInfo.refund.toFixed(2)}`);
    
    if (transaction.paymentMethod === 'cash') {
      toast.info(`💵 Refund $${refundInfo.refund.toFixed(2)} to ${member.name}\n${refundInfo.reason}`);
    } else {
      toast.info(`💳 Credit card refund: $${refundInfo.refund.toFixed(2)}\n${refundInfo.reason}`);
    }

    loadData();
  };

  const stats = {
    totalShabbosBooks: shabbosBooks.reduce((sum, b) => sum + b.copies, 0),
    availableShabbosBooks: shabbosBooks.reduce((sum, b) => sum + b.availableCopies, 0),
    activeCheckouts: activeCheckouts.length,
    totalDepositsHeld: activeCheckouts.reduce((sum, t) => sum + (t.depositPaid || 0), 0),
  };

  return (
    <div className="space-y-6">
      <div>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Shabbos Book Lending</h1>
            <p className="text-gray-600 mt-1">Manage Shabbos book checkouts with deposits</p>
            {!isShabbosCheckoutAllowed() && (
              <div className="mt-2 inline-flex items-center gap-2 bg-yellow-50 text-yellow-800 text-sm px-3 py-1 rounded-lg">
                <AlertCircle className="w-4 h-4" />
                Checkouts available Sunday-Friday only
              </div>
            )}
          </div>
          <button
            onClick={() => setShowFormUpload(true)}
            className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center gap-2"
          >
            <Upload className="w-4 h-4" />
            Upload Shabbos Form
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Shabbos Books</p>
              <p className="text-3xl font-semibold text-gray-900 mt-2">{stats.totalShabbosBooks}</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <BookOpen className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Available Now</p>
              <p className="text-3xl font-semibold text-gray-900 mt-2">{stats.availableShabbosBooks}</p>
            </div>
            <div className="bg-green-100 p-3 rounded-lg">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Active Checkouts</p>
              <p className="text-3xl font-semibold text-gray-900 mt-2">{stats.activeCheckouts}</p>
            </div>
            <div className="bg-purple-100 p-3 rounded-lg">
              <Calendar className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Deposits Held</p>
              <p className="text-3xl font-semibold text-gray-900 mt-2">${stats.totalDepositsHeld.toFixed(2)}</p>
            </div>
            <div className="bg-yellow-100 p-3 rounded-lg">
              <DollarSign className="w-6 h-6 text-yellow-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Category Rules */}
      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg border border-blue-200 p-6">
        <h2 className="text-lg font-semibold text-blue-900 mb-4">📖 Shabbos Lending Rules</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {Object.values(SHABBOS_RULES).filter(r => r.category !== 'regular').map(rule => (
            <div key={rule.category} className="bg-white rounded-lg p-4 border border-blue-100">
              <h3 className="font-medium text-gray-900">{rule.description}</h3>
              <div className="mt-2 space-y-1 text-sm text-gray-600">
                <p>💵 Deposit: ${rule.depositRange[0]}{rule.depositRange[1] !== rule.depositRange[0] && `-$${rule.depositRange[1]}`}</p>
                <p>📚 Max: {rule.maxPerWeek === 999 ? 'Unlimited' : `${rule.maxPerWeek}/week`}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-4 bg-white rounded-lg p-4 border border-blue-100">
          <h3 className="font-medium text-gray-900 mb-2">⏰ Return Schedule</h3>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>✅ Return by Monday 1:30 PM: 25¢ reduction</li>
            <li>📅 Each day late: Additional $1.00 reduction from deposit</li>
            <li>🕐 Checkouts available Sunday-Friday only</li>
          </ul>
        </div>
      </div>

      {/* Available Books */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Available Shabbos Books</h2>
        {shabbosBooks.filter(b => b.availableCopies > 0).length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {shabbosBooks.filter(b => b.availableCopies > 0).map(book => {
              const rule = SHABBOS_RULES[book.shabbosCategory!];
              return (
                <div key={book.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{book.title}</h3>
                      <p className="text-sm text-gray-600">{book.author}</p>
                    </div>
                    <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">
                      {rule.description}
                    </span>
                  </div>
                  
                  <div className="space-y-2 mb-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Deposit:</span>
                      <span className="font-semibold text-green-600">${book.depositAmount?.toFixed(2) || rule.depositRange[0].toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Available:</span>
                      <span className="font-medium">{book.availableCopies}/{book.copies}</span>
                    </div>
                  </div>

                  <button
                    onClick={() => setSelectedBook(book)}
                    disabled={!isShabbosCheckoutAllowed()}
                    className={`w-full px-4 py-2 rounded-lg transition-colors ${
                      isShabbosCheckoutAllowed()
                        ? 'bg-blue-600 text-white hover:bg-blue-700'
                        : 'bg-gray-200 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    {isShabbosCheckoutAllowed() ? 'Checkout' : 'Sunday-Friday Only'}
                  </button>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="text-center text-gray-500 py-8">No Shabbos books available at this time</p>
        )}
      </div>

      {/* Active Checkouts */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <Clock className="w-5 h-5 text-purple-600" />
          Active Shabbos Checkouts
        </h2>
        {activeCheckouts.length > 0 ? (
          <div className="space-y-3">
            {activeCheckouts.map(transaction => {
              const book = books.find(b => b.id === transaction.bookId);
              const member = members.find(m => m.id === transaction.memberId);
              if (!book || !member) return null;

              const timeRemaining = transaction.returnDeadline 
                ? formatTimeRemaining(transaction.returnDeadline)
                : '';
              const isOverdue = transaction.returnDeadline && new Date(transaction.returnDeadline) < new Date();

              return (
                <div key={transaction.id} className={`border rounded-lg p-4 ${isOverdue ? 'border-red-300 bg-red-50' : 'border-gray-200'}`}>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{book.title}</h3>
                      <p className="text-sm text-gray-600">{member.name} ({member.membershipId})</p>
                      <div className="mt-2 flex flex-wrap gap-2 text-xs">
                        <span className="bg-gray-100 px-2 py-1 rounded">
                          Checkout: {new Date(transaction.checkoutDate).toLocaleDateString()}
                        </span>
                        <span className={`px-2 py-1 rounded ${isOverdue ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'}`}>
                          {timeRemaining}
                        </span>
                        <span className="bg-green-100 text-green-700 px-2 py-1 rounded">
                          ${transaction.depositPaid?.toFixed(2)} {transaction.paymentMethod === 'cash' ? '💵' : '💳'}
                        </span>
                      </div>
                    </div>
                    <button
                      onClick={() => handleReturn(transaction)}
                      className="ml-4 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
                    >
                      <CheckCircle className="w-4 h-4" />
                      Return
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <p className="text-center text-gray-500 py-8">No active checkouts</p>
        )}
      </div>

      {selectedBook && (
        <ShabbosCheckoutDialog
          book={selectedBook}
          members={members.filter(m => m.status === 'active')}
          onCheckout={(memberId, paymentMethod, creditCardId) => 
            handleCheckout(selectedBook, memberId, paymentMethod, creditCardId)
          }
          onClose={() => setSelectedBook(null)}
        />
      )}

      {showFormUpload && (
        <FormUploadDialog
          formType="shabbos"
          onProcess={(data) => {
            setShowFormUpload(false);
          }}
          onClose={() => setShowFormUpload(false)}
        />
      )}
    </div>
  );
}