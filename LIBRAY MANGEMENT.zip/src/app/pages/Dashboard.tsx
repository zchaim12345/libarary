import { useEffect, useState } from 'react';
import { BookOpen, Users, ArrowLeftRight, AlertCircle, TrendingUp, Clock, Calendar } from 'lucide-react';
import { DashboardStats, Transaction, Member } from '../types';
import { getBooks, getMembers, getTransactions } from '../lib/storage';

export function Dashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    totalBooks: 0,
    totalMembers: 0,
    booksCheckedOut: 0,
    overdueBooks: 0,
    availableBooks: 0,
    activeMembers: 0,
    bannedMembers: 0,
  });

  const [recentActivity, setRecentActivity] = useState<Array<{
    id: string;
    type: string;
    message: string;
    time: string;
  }>>([]);

  const [upcomingDueDates, setUpcomingDueDates] = useState<Array<{
    memberName: string;
    bookTitle: string;
    dueDate: string;
    daysRemaining: number;
    isShabbos: boolean;
  }>>([]);

  useEffect(() => {
    const books = getBooks();
    const members = getMembers();
    const transactions = getTransactions();

    const now = new Date();
    const activeTrans = transactions.filter(t => t.status === 'borrowed');
    const overdue = activeTrans.filter(t => new Date(t.dueDate) < now);
    const bannedCount = members.filter(m => m.status === 'banned').length;

    setStats({
      totalBooks: books.reduce((sum, b) => sum + b.copies, 0),
      totalMembers: members.length,
      booksCheckedOut: activeTrans.length,
      overdueBooks: overdue.length,
      availableBooks: books.reduce((sum, b) => sum + b.availableCopies, 0),
      activeMembers: members.filter(m => m.status === 'active').length,
      bannedMembers: bannedCount,
    });

    // Generate recent activity
    const activity = transactions
      .slice(-5)
      .reverse()
      .map(t => {
        const book = books.find(b => b.id === t.bookId);
        const member = members.find(m => m.id === t.memberId);
        return {
          id: t.id,
          type: t.status,
          message: `${member?.name || 'Unknown'} ${t.status === 'returned' ? 'returned' : 'borrowed'} "${book?.title || 'Unknown'}"`,
          time: new Date(t.checkoutDate).toLocaleString(),
        };
      });

    setRecentActivity(activity);

    // Calculate upcoming due dates
    const fourDaysFromNow = new Date();
    fourDaysFromNow.setDate(now.getDate() + 4);
    fourDaysFromNow.setHours(23, 59, 59, 999);

    const upcoming = activeTrans
      .filter(t => {
        const dueDate = new Date(t.dueDate);
        return dueDate <= fourDaysFromNow && dueDate >= now;
      })
      .map(t => {
        const book = books.find(b => b.id === t.bookId);
        const member = members.find(m => m.id === t.memberId);
        const dueDate = new Date(t.dueDate);
        const daysRemaining = Math.ceil((dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
        
        return {
          memberName: member?.name || 'Unknown',
          bookTitle: book?.title || 'Unknown',
          dueDate: dueDate.toLocaleDateString(),
          daysRemaining,
          isShabbos: !!t.isShabbosCheckout,
        };
      })
      .sort((a, b) => a.daysRemaining - b.daysRemaining);

    setUpcomingDueDates(upcoming);
  }, []);

  const statCards = [
    {
      title: 'Total Books',
      value: stats.totalBooks,
      icon: BookOpen,
      color: 'bg-blue-500',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-700',
    },
    {
      title: 'Total Members',
      value: stats.totalMembers,
      icon: Users,
      color: 'bg-green-500',
      bgColor: 'bg-green-50',
      textColor: 'text-green-700',
    },
    {
      title: 'Checked Out',
      value: stats.booksCheckedOut,
      icon: ArrowLeftRight,
      color: 'bg-purple-500',
      bgColor: 'bg-purple-50',
      textColor: 'text-purple-700',
    },
    {
      title: 'Overdue Books',
      value: stats.overdueBooks,
      icon: AlertCircle,
      color: 'bg-red-500',
      bgColor: 'bg-red-50',
      textColor: 'text-red-700',
    },
    {
      title: 'Available Books',
      value: stats.availableBooks,
      icon: TrendingUp,
      color: 'bg-teal-500',
      bgColor: 'bg-teal-50',
      textColor: 'text-teal-700',
    },
    {
      title: 'Active Members',
      value: stats.activeMembers,
      icon: Users,
      color: 'bg-orange-500',
      bgColor: 'bg-orange-50',
      textColor: 'text-orange-700',
    },
    {
      title: 'Banned Members',
      value: stats.bannedMembers,
      icon: Users,
      color: 'bg-red-500',
      bgColor: 'bg-red-50',
      textColor: 'text-red-700',
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-1">Welcome to LibraryOS - Your complete library management solution</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {statCards.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.title} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">{stat.title}</p>
                  <p className="text-3xl font-semibold text-gray-900 mt-2">{stat.value}</p>
                </div>
                <div className={`${stat.bgColor} p-3 rounded-lg`}>
                  <Icon className={`w-6 h-6 ${stat.textColor}`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <a
            href="/books"
            className="p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-all text-center"
          >
            <BookOpen className="w-6 h-6 mx-auto text-blue-600 mb-2" />
            <p className="font-medium text-gray-900">Add New Book</p>
            <p className="text-sm text-gray-500 mt-1">Scan or enter book details</p>
          </a>
          <a
            href="/members"
            className="p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-green-500 hover:bg-green-50 transition-all text-center"
          >
            <Users className="w-6 h-6 mx-auto text-green-600 mb-2" />
            <p className="font-medium text-gray-900">Register Member</p>
            <p className="text-sm text-gray-500 mt-1">Add new library member</p>
          </a>
          <a
            href="/transactions"
            className="p-4 border-2 border-dashed border-gray-300 rounded-lg hover:border-purple-500 hover:bg-purple-50 transition-all text-center"
          >
            <ArrowLeftRight className="w-6 h-6 mx-auto text-purple-600 mb-2" />
            <p className="font-medium text-gray-900">Check Out Book</p>
            <p className="text-sm text-gray-500 mt-1">Issue book to member</p>
          </a>
        </div>
      </div>

      {/* Upcoming Due Dates */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-orange-600" />
          Books Due Soon (Next 4 Days)
        </h2>
        {upcomingDueDates.length > 0 ? (
          <div className="space-y-3">
            {upcomingDueDates.map((item, index) => (
              <div 
                key={index} 
                className={`p-3 rounded-lg border ${
                  item.isShabbos 
                    ? 'bg-blue-50 border-blue-200' 
                    : 'bg-gray-50 border-gray-200'
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{item.memberName}</p>
                    <p className="text-sm text-gray-600 mt-1">"{item.bookTitle}"</p>
                    <div className="flex items-center gap-2 mt-2">
                      {item.isShabbos && (
                        <span className="bg-blue-100 text-blue-700 text-xs px-2 py-1 rounded">
                          Shabbos - Monday 1:30 PM
                        </span>
                      )}
                      <span className="text-xs text-gray-600">
                        Due: {item.dueDate}
                      </span>
                    </div>
                  </div>
                  <div className={`text-right ml-4 ${
                    item.daysRemaining === 0 ? 'text-red-600' :
                    item.daysRemaining === 1 ? 'text-orange-600' :
                    'text-gray-600'
                  }`}>
                    <p className="text-2xl font-semibold">{item.daysRemaining}</p>
                    <p className="text-xs">day{item.daysRemaining !== 1 ? 's' : ''}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-gray-500 py-8">No books due in the next 4 days</p>
        )}
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
          <Clock className="w-5 h-5 text-gray-600" />
          Recent Activity
        </h2>
        {recentActivity.length > 0 ? (
          <div className="space-y-3">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                <div className={`w-2 h-2 rounded-full mt-2 ${activity.type === 'returned' ? 'bg-green-500' : 'bg-blue-500'}`} />
                <div className="flex-1">
                  <p className="text-sm text-gray-900">{activity.message}</p>
                  <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-center text-gray-500 py-8">No recent activity</p>
        )}
      </div>
    </div>
  );
}