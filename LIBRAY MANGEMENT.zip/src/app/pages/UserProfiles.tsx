import { useEffect, useState } from 'react';
import { User, CreditCard as CreditCardIcon, IdCard, Plus, Trash2 } from 'lucide-react';
import { Member, CreditCard } from '../types';
import { getMembers, updateMember } from '../lib/storage';
import { generateUserBarcode } from '../lib/barcode-generator';
import { UserCardDialog } from '../components/UserCardDialog';
import { CreditCardDialog } from '../components/CreditCardDialog';
import { toast } from 'sonner';

export function UserProfiles() {
  const [members, setMembers] = useState<Member[]>([]);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [showCardDialog, setShowCardDialog] = useState(false);
  const [showCreditCardDialog, setShowCreditCardDialog] = useState(false);

  useEffect(() => {
    loadMembers();
  }, []);

  const loadMembers = () => {
    const allMembers = getMembers();
    // Ensure all members have barcodes
    allMembers.forEach(member => {
      if (!member.cardBarcode) {
        member.cardBarcode = generateUserBarcode(member.membershipId);
        updateMember(member.id, member);
      }
    });
    setMembers(allMembers);
  };

  const handleGenerateCard = (member: Member) => {
    if (!member.cardBarcode) {
      const barcode = generateUserBarcode(member.membershipId);
      updateMember(member.id, { ...member, cardBarcode: barcode });
      loadMembers();
    }
    setSelectedMember(member);
    setShowCardDialog(true);
  };

  const handleAddCreditCard = (member: Member) => {
    setSelectedMember(member);
    setShowCreditCardDialog(true);
  };

  const handleSaveCreditCard = (cardData: Omit<CreditCard, 'id'>) => {
    if (!selectedMember) return;

    const newCard: CreditCard = {
      ...cardData,
      id: Date.now().toString(),
    };

    const existingCards = selectedMember.creditCards || [];
    
    // If this is set as default, unset others
    const updatedCards = cardData.isDefault
      ? [...existingCards.map(c => ({ ...c, isDefault: false })), newCard]
      : [...existingCards, newCard];

    updateMember(selectedMember.id, {
      ...selectedMember,
      creditCards: updatedCards,
    });

    toast.success('💳 Credit card added successfully - Available for Shabbos deposits');
    loadMembers();
    setShowCreditCardDialog(false);
    setSelectedMember(null);
  };

  const handleDeleteCreditCard = (member: Member, cardId: string) => {
    if (!confirm('Remove this credit card?')) return;

    const updatedCards = (member.creditCards || []).filter(c => c.id !== cardId);
    
    updateMember(member.id, {
      ...member,
      creditCards: updatedCards,
    });

    toast.success('Credit card removed');
    loadMembers();
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-gray-900">User Profiles</h1>
        <p className="text-gray-600 mt-1">Manage member cards and payment methods</p>
      </div>

      {/* Member Cards */}
      <div className="grid grid-cols-1 gap-6">
        {members.map(member => (
          <div key={member.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-center gap-4">
                <div className="bg-blue-100 p-4 rounded-full">
                  <User className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-gray-900">{member.name}</h2>
                  <p className="text-sm text-gray-600">{member.email}</p>
                  <p className="text-sm text-gray-500">{member.membershipId}</p>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                member.status === 'active' 
                  ? 'bg-green-100 text-green-700'
                  : member.status === 'suspended'
                  ? 'bg-red-100 text-red-700'
                  : 'bg-gray-100 text-gray-700'
              }`}>
                {member.status}
              </span>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Member Card */}
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-medium text-gray-900 flex items-center gap-2">
                    <IdCard className="w-5 h-5 text-blue-600" />
                    Member Card
                  </h3>
                  <button
                    onClick={() => handleGenerateCard(member)}
                    className="text-blue-600 hover:text-blue-700 text-sm font-medium"
                  >
                    View/Print
                  </button>
                </div>
                {member.cardBarcode ? (
                  <div className="bg-gray-50 rounded p-3 text-center">
                    <p className="text-xs text-gray-600 mb-1">Barcode Number</p>
                    <p className="font-mono text-sm font-medium text-gray-900">{member.cardBarcode}</p>
                    {member.memberPIN && (
                      <div className="mt-2 pt-2 border-t border-gray-200">
                        <p className="text-xs text-gray-600 mb-1">Member PIN</p>
                        <p className="font-mono text-lg font-semibold text-green-700 tracking-widest">{member.memberPIN}</p>
                      </div>
                    )}
                    <p className="text-xs text-green-600 mt-2">✓ Card generated</p>
                  </div>
                ) : (
                  <div className="bg-yellow-50 rounded p-3 text-center">
                    <p className="text-sm text-yellow-700">Card not generated</p>
                  </div>
                )}
              </div>

              {/* Credit Cards */}
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-medium text-gray-900 flex items-center gap-2">
                    <CreditCardIcon className="w-5 h-5 text-green-600" />
                    Payment Methods
                  </h3>
                  <button
                    onClick={() => handleAddCreditCard(member)}
                    className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center gap-1"
                  >
                    <Plus className="w-4 h-4" />
                    Add Card
                  </button>
                </div>
                <div className="space-y-2">
                  {member.creditCards && member.creditCards.length > 0 ? (
                    member.creditCards.map(card => (
                      <div key={card.id} className="bg-gray-50 rounded p-3 flex items-center justify-between">
                        <div className="flex-1">
                          <p className="text-sm font-medium text-gray-900">
                            {card.cardType} •••• {card.lastFour}
                          </p>
                          <p className="text-xs text-gray-600">
                            Expires {card.expiryMonth}/{card.expiryYear}
                            {card.isDefault && <span className="ml-2 text-blue-600">• Default</span>}
                          </p>
                        </div>
                        <button
                          onClick={() => handleDeleteCreditCard(member, card.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))
                  ) : (
                    <div className="bg-gray-50 rounded p-3 text-center">
                      <p className="text-sm text-gray-500">No cards on file</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Member Stats */}
            <div className="mt-6 pt-6 border-t border-gray-200 grid grid-cols-3 gap-4">
              <div className="text-center">
                <p className="text-2xl font-semibold text-gray-900">{member.depositBalance?.toFixed(2) || '0.00'}</p>
                <p className="text-xs text-gray-600 mt-1">Deposit Balance</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-semibold text-gray-900">{member.phone}</p>
                <p className="text-xs text-gray-600 mt-1">Phone Number</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-semibold text-gray-900">
                  {new Date(member.joinDate).toLocaleDateString()}
                </p>
                <p className="text-xs text-gray-600 mt-1">Member Since</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showCardDialog && selectedMember && (
        <UserCardDialog
          member={selectedMember}
          onClose={() => {
            setShowCardDialog(false);
            setSelectedMember(null);
          }}
        />
      )}

      {showCreditCardDialog && selectedMember && (
        <CreditCardDialog
          existingCards={selectedMember.creditCards || []}
          onSave={handleSaveCreditCard}
          onClose={() => {
            setShowCreditCardDialog(false);
            setSelectedMember(null);
          }}
        />
      )}
    </div>
  );
}