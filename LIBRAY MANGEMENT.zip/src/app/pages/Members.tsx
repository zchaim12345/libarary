import { useEffect, useState } from 'react';
import { Plus, Search, Edit, Trash2, User, Mail, Phone, CreditCard, Scan, Upload } from 'lucide-react';
import { Member } from '../types';
import { getMembers, addMember, updateMember, deleteMember } from '../lib/storage';
import { AddMemberDialog } from '../components/AddMemberDialog';
import { BannedAlert } from '../components/BannedAlert';
import { BarcodeScanner } from '../components/BarcodeScanner';
import { FormUploadDialog } from '../components/FormUploadDialog';
import { checkAdminSession } from '../lib/admin';
import { toast } from 'sonner';

export function Members() {
  const [members, setMembers] = useState<Member[]>([]);
  const [filteredMembers, setFilteredMembers] = useState<Member[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | Member['status']>('all');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showFormUpload, setShowFormUpload] = useState(false);
  const [editingMember, setEditingMember] = useState<Member | undefined>();
  const [bannedMember, setBannedMember] = useState<Member | null>(null);
  const [showScanner, setShowScanner] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    loadMembers();
    setIsAdmin(checkAdminSession());
  }, []);

  useEffect(() => {
    let filtered = members;

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        member =>
          member.name.toLowerCase().includes(query) ||
          member.email.toLowerCase().includes(query) ||
          member.membershipId.toLowerCase().includes(query)
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(member => member.status === statusFilter);
    }

    setFilteredMembers(filtered);
  }, [members, searchQuery, statusFilter]);

  const loadMembers = () => {
    setMembers(getMembers());
  };

  const handleSaveMember = (memberData: Omit<Member, 'id'>) => {
    if (editingMember) {
      updateMember(editingMember.id, { ...memberData, id: editingMember.id });
    } else {
      addMember({ ...memberData, id: Date.now().toString() });
    }
    loadMembers();
    setShowAddDialog(false);
    setEditingMember(undefined);
  };

  const handleAddMemberClick = () => {
    if (!isAdmin) {
      toast.error('Admin access required to add members');
      return;
    }
    setEditingMember(undefined);
    setShowAddDialog(true);
  };

  const handleEditMemberClick = (member: Member) => {
    if (!isAdmin) {
      toast.error('Admin access required to edit members');
      return;
    }
    setEditingMember(member);
    setShowAddDialog(true);
  };

  const handleDeleteMember = (id: string) => {
    if (!isAdmin) {
      toast.error('Admin access required to delete members');
      return;
    }
    if (confirm('Are you sure you want to delete this member?')) {
      deleteMember(id);
      loadMembers();
    }
  };

  const handleScan = (code: string) => {
    const member = members.find(m => m.cardBarcode === code || m.membershipId === code);
    if (member) {
      if (member.status === 'banned') {
        setBannedMember(member);
      } else {
        setEditingMember(member);
        setShowAddDialog(true);
      }
    } else {
      alert('Member not found with this barcode');
    }
    setShowScanner(false);
  };

  const getStatusColor = (status: Member['status']) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-700';
      case 'inactive':
        return 'bg-gray-100 text-gray-700';
      case 'suspended':
        return 'bg-orange-100 text-orange-700';
      case 'banned':
        return 'bg-red-100 text-red-700';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Member Management</h1>
          <p className="text-gray-600 mt-1">Manage library members and their information</p>
          {!isAdmin && (
            <p className="text-sm text-orange-600 mt-1">🔒 Admin access required to add/edit members</p>
          )}
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowScanner(true)}
            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
          >
            <Scan className="w-4 h-4" />
            Scan Member
          </button>
          {isAdmin && (
            <>
              <button
                onClick={() => setShowFormUpload(true)}
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center gap-2"
              >
                <Upload className="w-4 h-4" />
                Upload Form
              </button>
              <button
                onClick={handleAddMemberClick}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Add Member
              </button>
            </>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search members by name, email, or membership ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Status</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="suspended">Suspended</option>
              <option value="banned">Banned</option>
            </select>
          </div>
        </div>
      </div>

      {/* Members Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredMembers.map((member) => (
          <div key={member.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-start gap-3">
                <div className="bg-blue-100 p-3 rounded-lg">
                  <User className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900">{member.name}</h3>
                  <span className={`inline-block mt-1 px-2 py-1 text-xs rounded-full ${getStatusColor(member.status)}`}>
                    {member.status}
                  </span>
                </div>
              </div>
            </div>

            <div className="space-y-2 mb-4">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Mail className="w-4 h-4" />
                <span className="truncate">{member.email}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Phone className="w-4 h-4" />
                <span>{member.phone}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <CreditCard className="w-4 h-4" />
                <span>{member.membershipId}</span>
              </div>
              <div className="text-xs text-gray-500 mt-2">
                Joined: {new Date(member.joinDate).toLocaleDateString()}
              </div>
            </div>

            <div className="pt-4 border-t border-gray-200 flex gap-2">
              <button
                onClick={() => handleEditMemberClick(member)}
                className="flex-1 px-3 py-2 text-sm border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
              >
                <Edit className="w-4 h-4" />
                Edit
              </button>
              <button
                onClick={() => handleDeleteMember(member.id)}
                className="flex-1 px-3 py-2 text-sm border border-red-300 text-red-700 rounded-lg hover:bg-red-50 transition-colors flex items-center justify-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredMembers.length === 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
          <User className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">
            {searchQuery || statusFilter !== 'all'
              ? 'No members found matching your criteria'
              : 'No members registered yet. Add your first member!'}
          </p>
        </div>
      )}

      {showAddDialog && (
        <AddMemberDialog
          member={editingMember}
          onSave={handleSaveMember}
          onClose={() => {
            setShowAddDialog(false);
            setEditingMember(undefined);
          }}
        />
      )}

      {showScanner && (
        <BarcodeScanner
          onScan={handleScan}
          onClose={() => setShowScanner(false)}
        />
      )}

      {showFormUpload && (
        <FormUploadDialog
          formType="member"
          onProcess={(data) => {
            setShowFormUpload(false);
            toast.info('Form processed. Please add member manually.');
          }}
          onClose={() => setShowFormUpload(false)}
        />
      )}

      {bannedMember && (
        <BannedAlert
          member={bannedMember}
          onClose={() => setBannedMember(null)}
        />
      )}
    </div>
  );
}