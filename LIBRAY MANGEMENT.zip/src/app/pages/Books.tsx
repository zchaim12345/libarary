import { useEffect, useState } from 'react';
import { Plus, Search, Edit, Trash2, BookOpen, Scan, Upload } from 'lucide-react';
import { Book } from '../types';
import { getBooks, addBook, updateBook, deleteBook } from '../lib/storage';
import { AddBookDialog } from '../components/AddBookDialog';
import { BarcodeScanner } from '../components/BarcodeScanner';
import { FormUploadDialog } from '../components/FormUploadDialog';
import { checkAdminSession } from '../lib/admin';
import { toast } from 'sonner';

export function Books() {
  const [books, setBooks] = useState<Book[]>([]);
  const [filteredBooks, setFilteredBooks] = useState<Book[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showScanner, setShowScanner] = useState(false);
  const [showFormUpload, setShowFormUpload] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | undefined>();
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    loadBooks();
    setIsAdmin(checkAdminSession());
  }, []);

  useEffect(() => {
    let filtered = books;

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        book =>
          book.title.toLowerCase().includes(query) ||
          book.author.toLowerCase().includes(query) ||
          book.isbn.toLowerCase().includes(query)
      );
    }

    if (categoryFilter !== 'all') {
      filtered = filtered.filter(book => book.category === categoryFilter);
    }

    setFilteredBooks(filtered);
  }, [books, searchQuery, categoryFilter]);

  const loadBooks = () => {
    setBooks(getBooks());
  };

  const handleSaveBook = (bookData: Omit<Book, 'id'>) => {
    if (editingBook) {
      updateBook(editingBook.id, { ...bookData, id: editingBook.id });
    } else {
      addBook({ ...bookData, id: Date.now().toString() });
    }
    loadBooks();
    setShowAddDialog(false);
    setEditingBook(undefined);
  };

  const handleAddBookClick = () => {
    if (!isAdmin) {
      toast.error('Admin access required to add books');
      return;
    }
    setEditingBook(undefined);
    setShowAddDialog(true);
  };

  const handleEditBookClick = (book: Book) => {
    if (!isAdmin) {
      toast.error('Admin access required to edit books');
      return;
    }
    setEditingBook(book);
    setShowAddDialog(true);
  };

  const handleDeleteBook = (id: string) => {
    if (!isAdmin) {
      toast.error('Admin access required to delete books');
      return;
    }
    if (confirm('Are you sure you want to delete this book?')) {
      deleteBook(id);
      loadBooks();
    }
  };

  const handleScan = (code: string) => {
    const book = books.find(b => b.isbn === code);
    if (book) {
      setEditingBook(book);
      setShowAddDialog(true);
    } else {
      // Pre-fill ISBN for new book
      setEditingBook({ isbn: code } as Book);
      setShowAddDialog(true);
    }
    setShowScanner(false);
  };

  const categories = ['all', ...Array.from(new Set(books.map(b => b.category)))];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Book Management</h1>
          <p className="text-gray-600 mt-1">Manage your library collection</p>
          {!isAdmin && (
            <p className="text-sm text-orange-600 mt-1">🔒 Admin access required to add/edit books</p>
          )}
        </div>
        <div className="flex gap-2">
          {isAdmin && (
            <>
              <button
                onClick={() => setShowFormUpload(true)}
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center gap-2"
              >
                <Upload className="w-4 h-4" />
                Upload Form
              </button>
              <button
                onClick={() => setShowScanner(true)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
              >
                <Scan className="w-4 h-4" />
                Scan Book
              </button>
              <button
                onClick={handleAddBookClick}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <Plus className="w-4 h-4" />
                Add Book
              </button>
            </>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search books by title, author, or ISBN..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          <div>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              {categories.map(cat => (
                <option key={cat} value={cat}>
                  {cat === 'all' ? 'All Categories' : cat}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Books Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredBooks.map((book) => (
          <div key={book.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
            <div className="flex items-start gap-4">
              <div className="bg-blue-100 p-3 rounded-lg flex-shrink-0">
                <BookOpen className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-semibold text-gray-900 truncate">{book.title}</h3>
                <p className="text-sm text-gray-600 truncate">{book.author}</p>
                <div className="mt-2 space-y-1">
                  <p className="text-xs text-gray-500">ISBN: {book.isbn}</p>
                  <p className="text-xs text-gray-500">Category: {book.category}</p>
                  <p className="text-xs text-gray-500">Year: {book.publishedYear}</p>
                </div>
                <div className="mt-3 flex items-center gap-4">
                  <div className="text-xs">
                    <span className="text-gray-600">Total: </span>
                    <span className="font-medium">{book.copies}</span>
                  </div>
                  <div className="text-xs">
                    <span className="text-gray-600">Available: </span>
                    <span className={`font-medium ${book.availableCopies > 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {book.availableCopies}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-gray-200 flex gap-2">
              <button
                onClick={() => handleEditBookClick(book)}
                className="flex-1 px-3 py-2 text-sm border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
              >
                <Edit className="w-4 h-4" />
                Edit
              </button>
              <button
                onClick={() => handleDeleteBook(book.id)}
                className="flex-1 px-3 py-2 text-sm border border-red-300 text-red-700 rounded-lg hover:bg-red-50 transition-colors flex items-center justify-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                Delete
              </button>
            </div>
          </div>
        ))}
      </div>

      {filteredBooks.length === 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
          <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-gray-600">
            {searchQuery || categoryFilter !== 'all'
              ? 'No books found matching your criteria'
              : 'No books in the library yet. Add your first book!'}
          </p>
        </div>
      )}

      {showAddDialog && (
        <AddBookDialog
          book={editingBook}
          onSave={handleSaveBook}
          onClose={() => {
            setShowAddDialog(false);
            setEditingBook(undefined);
          }}
        />
      )}

      {showScanner && (
        <BarcodeScanner
          onScan={handleScan}
          onClose={() => setShowScanner(false)}
        />
      )}

      {showFormUpload && (
        <FormUploadDialog
          formType="book"
          onProcess={(data) => {
            setShowFormUpload(false);
            toast.info('Form processed. Please add book manually.');
          }}
          onClose={() => setShowFormUpload(false)}
        />
      )}
    </div>
  );
}