import { useEffect, useState } from 'react';
import { Plus, Search, CheckCircle, AlertTriangle, Calendar, Upload } from 'lucide-react';
import { Transaction, Book, Member } from '../types';
import { 
  getTransactions, 
  getBooks, 
  getMembers, 
  addTransaction, 
  updateTransaction,
  updateBook 
} from '../lib/storage';
import { CheckoutDialog } from '../components/CheckoutDialog';
import { FormUploadDialog } from '../components/FormUploadDialog';

export function Transactions() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [books, setBooks] = useState<Book[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [filteredTransactions, setFilteredTransactions] = useState<Transaction[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | Transaction['status']>('all');
  const [showCheckoutDialog, setShowCheckoutDialog] = useState(false);
  const [showFormUpload, setShowFormUpload] = useState(false);
  const [formType, setFormType] = useState<'borrowing' | 'return'>('borrowing');

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    let filtered = transactions;

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(transaction => {
        const book = books.find(b => b.id === transaction.bookId);
        const member = members.find(m => m.id === transaction.memberId);
        return (
          book?.title.toLowerCase().includes(query) ||
          member?.name.toLowerCase().includes(query) ||
          member?.membershipId.toLowerCase().includes(query)
        );
      });
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(t => t.status === statusFilter);
    }

    // Update overdue status
    const now = new Date();
    filtered = filtered.map(t => {
      if (t.status === 'borrowed' && new Date(t.dueDate) < now) {
        return { ...t, status: 'overdue' as const };
      }
      return t;
    });

    // Sort by checkout date (most recent first)
    filtered.sort((a, b) => new Date(b.checkoutDate).getTime() - new Date(a.checkoutDate).getTime());

    setFilteredTransactions(filtered);
  }, [transactions, books, members, searchQuery, statusFilter]);

  const loadData = () => {
    setTransactions(getTransactions());
    setBooks(getBooks());
    setMembers(getMembers());
  };

  const handleCheckout = (bookId: string, memberId: string, dueDate: string) => {
    const book = books.find(b => b.id === bookId);
    if (!book || book.availableCopies <= 0) {
      alert('This book is not available');
      return;
    }

    // Create transaction
    const transaction: Transaction = {
      id: Date.now().toString(),
      bookId,
      memberId,
      checkoutDate: new Date().toISOString(),
      dueDate: new Date(dueDate).toISOString(),
      status: 'borrowed',
    };

    addTransaction(transaction);

    // Update book available copies
    updateBook(bookId, {
      ...book,
      availableCopies: book.availableCopies - 1,
    });

    loadData();
    setShowCheckoutDialog(false);
  };

  const handleReturn = (transaction: Transaction) => {
    const book = books.find(b => b.id === transaction.bookId);
    if (!book) return;

    // Calculate fine if overdue
    const now = new Date();
    const dueDate = new Date(transaction.dueDate);
    let fine = 0;
    
    if (now > dueDate) {
      const daysLate = Math.ceil((now.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24));
      fine = daysLate * 0.5; // $0.50 per day
    }

    // Update transaction
    updateTransaction(transaction.id, {
      ...transaction,
      returnDate: now.toISOString(),
      status: 'returned',
      fine: fine > 0 ? fine : undefined,
    });

    // Update book available copies
    updateBook(book.id, {
      ...book,
      availableCopies: book.availableCopies + 1,
    });

    if (fine > 0) {
      alert(`Book returned with a late fee of $${fine.toFixed(2)}`);
    }

    loadData();
  };

  const getBookTitle = (bookId: string) => {
    return books.find(b => b.id === bookId)?.title || 'Unknown Book';
  };

  const getMemberName = (memberId: string) => {
    return members.find(m => m.id === memberId)?.name || 'Unknown Member';
  };

  const getMembershipId = (memberId: string) => {
    return members.find(m => m.id === memberId)?.membershipId || '';
  };

  const getStatusColor = (status: Transaction['status']) => {
    switch (status) {
      case 'borrowed':
        return 'bg-blue-100 text-blue-700';
      case 'returned':
        return 'bg-green-100 text-green-700';
      case 'overdue':
        return 'bg-red-100 text-red-700';
    }
  };

  const getDaysUntilDue = (dueDate: string) => {
    const due = new Date(dueDate);
    const now = new Date();
    const diff = Math.ceil((due.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return diff;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Transactions</h1>
          <p className="text-gray-600 mt-1">Manage book checkouts and returns</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => {
              setFormType('borrowing');
              setShowFormUpload(true);
            }}
            className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center gap-2"
          >
            <Upload className="w-4 h-4" />
            Upload Borrowing
          </button>
          <button
            onClick={() => {
              setFormType('return');
              setShowFormUpload(true);
            }}
            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
          >
            <Upload className="w-4 h-4" />
            Upload Return
          </button>
          <button
            onClick={() => setShowCheckoutDialog(true)}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            Check Out Book
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search by book title or member name..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
          <div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Status</option>
              <option value="borrowed">Borrowed</option>
              <option value="overdue">Overdue</option>
              <option value="returned">Returned</option>
            </select>
          </div>
        </div>
      </div>

      {/* Transactions List */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Book
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Member
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Checkout Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Due Date
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Action
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredTransactions.map((transaction) => {
                const daysUntilDue = getDaysUntilDue(transaction.dueDate);
                return (
                  <tr key={transaction.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {getBookTitle(transaction.bookId)}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{getMemberName(transaction.memberId)}</div>
                      <div className="text-xs text-gray-500">{getMembershipId(transaction.memberId)}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(transaction.checkoutDate).toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">
                        {new Date(transaction.dueDate).toLocaleDateString()}
                      </div>
                      {transaction.status === 'borrowed' && (
                        <div className={`text-xs ${daysUntilDue < 0 ? 'text-red-600' : daysUntilDue <= 3 ? 'text-orange-600' : 'text-gray-500'}`}>
                          {daysUntilDue < 0 
                            ? `${Math.abs(daysUntilDue)} days overdue`
                            : `${daysUntilDue} days left`
                          }
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 text-xs rounded-full ${getStatusColor(transaction.status)}`}>
                        {transaction.status}
                      </span>
                      {transaction.fine && (
                        <div className="text-xs text-red-600 mt-1">
                          Fine: ${transaction.fine.toFixed(2)}
                        </div>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                      {transaction.status === 'borrowed' || transaction.status === 'overdue' ? (
                        <button
                          onClick={() => handleReturn(transaction)}
                          className="px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700 transition-colors flex items-center gap-1"
                        >
                          <CheckCircle className="w-4 h-4" />
                          Return
                        </button>
                      ) : (
                        <span className="text-gray-500">
                          {transaction.returnDate && `Returned ${new Date(transaction.returnDate).toLocaleDateString()}`}
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredTransactions.length === 0 && (
          <div className="p-12 text-center">
            <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">
              {searchQuery || statusFilter !== 'all'
                ? 'No transactions found matching your criteria'
                : 'No transactions yet. Check out a book to get started!'}
            </p>
          </div>
        )}
      </div>

      {showCheckoutDialog && (
        <CheckoutDialog
          books={books}
          members={members}
          onCheckout={handleCheckout}
          onClose={() => setShowCheckoutDialog(false)}
        />
      )}

      {showFormUpload && (
        <FormUploadDialog
          formType={formType}
          onProcess={(data) => {
            setShowFormUpload(false);
          }}
          onClose={() => setShowFormUpload(false)}
        />
      )}
    </div>
  );
}