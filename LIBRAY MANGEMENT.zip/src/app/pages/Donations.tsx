import { useEffect, useState } from 'react';
import { Heart, DollarSign, Users, TrendingUp, Download } from 'lucide-react';
import { checkAdminSession } from '../lib/admin';

interface Donation {
  id: string;
  amount: number;
  donorName: string;
  paymentMethod: string;
  message: string;
  date: string;
}

export function Donations() {
  const [donations, setDonations] = useState<Donation[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    setIsAdmin(checkAdminSession());
    loadDonations();
  }, []);

  const loadDonations = () => {
    const stored = localStorage.getItem('library_donations');
    if (stored) {
      setDonations(JSON.parse(stored));
    }
  };

  const totalDonations = donations.reduce((sum, d) => sum + d.amount, 0);
  const donorCount = new Set(donations.map(d => d.donorName)).size;
  const avgDonation = donations.length > 0 ? totalDonations / donations.length : 0;

  const exportDonations = () => {
    const csv = [
      ['Date', 'Donor Name', 'Amount', 'Payment Method', 'Message'],
      ...donations.map(d => [
        new Date(d.date).toLocaleString(),
        d.donorName,
        `$${d.amount.toFixed(2)}`,
        d.paymentMethod,
        d.message || ''
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `donations-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (!isAdmin) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg border border-purple-200 p-12 text-center">
          <Heart className="w-16 h-16 text-purple-600 mx-auto mb-4" />
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">Support Our Library</h2>
          <p className="text-gray-600 mb-6">
            Help Zichron Chaim Library continue serving our community
          </p>
          <div className="bg-white rounded-lg p-6 max-w-md mx-auto">
            <h3 className="font-semibold mb-4">Ways to Donate</h3>
            <ul className="text-left space-y-2 text-sm text-gray-700">
              <li>💳 Credit Card - Secure online donation</li>
              <li>💵 Cash - In person at the library</li>
              <li>📝 Check - Mail to library address</li>
              <li>🏦 Bank Transfer - Contact for details</li>
            </ul>
          </div>
          <p className="text-sm text-gray-500 mt-4">
            🔒 Admin access required to view donation records
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-gray-900">Donation Management</h1>
          <p className="text-gray-600 mt-1">Track and manage library donations</p>
        </div>
        {donations.length > 0 && (
          <button
            onClick={exportDonations}
            className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Export CSV
          </button>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Donations</p>
              <p className="text-3xl font-semibold text-green-600 mt-2">
                ${totalDonations.toFixed(2)}
              </p>
            </div>
            <div className="bg-green-100 p-3 rounded-lg">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Donors</p>
              <p className="text-3xl font-semibold text-blue-600 mt-2">{donorCount}</p>
            </div>
            <div className="bg-blue-100 p-3 rounded-lg">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Average Donation</p>
              <p className="text-3xl font-semibold text-purple-600 mt-2">
                ${avgDonation.toFixed(2)}
              </p>
            </div>
            <div className="bg-purple-100 p-3 rounded-lg">
              <TrendingUp className="w-6 h-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Donation List */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200 p-4">
          <h2 className="text-lg font-semibold text-gray-900">Donation History</h2>
        </div>
        
        {donations.length > 0 ? (
          <div className="divide-y divide-gray-200">
            {donations.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((donation) => (
              <div key={donation.id} className="p-6 hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3">
                      <Heart className="w-5 h-5 text-purple-600 fill-current" />
                      <div>
                        <h3 className="font-semibold text-gray-900">{donation.donorName}</h3>
                        <p className="text-sm text-gray-600 mt-1">
                          {new Date(donation.date).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    {donation.message && (
                      <p className="text-sm text-gray-700 mt-3 ml-8 italic">
                        "{donation.message}"
                      </p>
                    )}
                  </div>
                  <div className="text-right ml-4">
                    <p className="text-2xl font-semibold text-green-600">
                      ${donation.amount.toFixed(2)}
                    </p>
                    <p className="text-xs text-gray-500 mt-1 capitalize">{donation.paymentMethod}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-12 text-center">
            <Heart className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">No donations recorded yet</p>
          </div>
        )}
      </div>

      {/* Donor Wall of Honor */}
      {donations.filter(d => d.amount >= 180 && d.donorName !== 'Anonymous').length > 0 && (
        <div className="bg-gradient-to-br from-yellow-50 to-orange-50 rounded-lg border border-yellow-200 p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            🏆 Donor Wall of Honor (Chai $180+)
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {donations
              .filter(d => d.amount >= 180 && d.donorName !== 'Anonymous')
              .sort((a, b) => b.amount - a.amount)
              .map((donation, index) => (
                <div key={donation.id} className="bg-white rounded-lg p-4 border border-yellow-300">
                  <div className="flex items-center gap-2 mb-2">
                    {index < 3 && (
                      <span className="text-2xl">
                        {index === 0 ? '🥇' : index === 1 ? '🥈' : '🥉'}
                      </span>
                    )}
                    <p className="font-semibold text-gray-900">{donation.donorName}</p>
                  </div>
                  <p className="text-lg font-semibold text-green-600">
                    ${donation.amount.toFixed(2)}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    {new Date(donation.date).toLocaleDateString()}
                  </p>
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}
