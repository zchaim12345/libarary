export interface Book {
  id: string;
  isbn: string;
  title: string;
  author: string;
  category: string;
  publishedYear: number;
  copies: number;
  availableCopies: number;
  addedDate: string;
  coverImage?: string;
  shabbosCategory?: ShabbosCategory;
  depositAmount?: number;
}

export type ShabbosCategory = 
  | 'comic-book' 
  | 'gedolim' 
  | 'inspirational' 
  | 'torah' 
  | 'jewish-history'
  | 'regular';

export interface Member {
  id: string;
  name: string;
  email: string;
  phone: string;
  membershipId: string;
  joinDate: string;
  status: 'active' | 'inactive' | 'suspended' | 'banned';
  cardBarcode?: string;
  memberPIN?: string;
  creditCards?: CreditCard[];
  depositBalance?: number;
  banInfo?: BanInfo;
}

export interface BanInfo {
  bannedDate: string;
  bannedBy: string;
  reason: string;
  notes?: string;
  isPermanent: boolean;
  unbanDate?: string;
}

export interface CreditCard {
  id: string;
  lastFour: string;
  cardType: string;
  expiryMonth: string;
  expiryYear: string;
  isDefault: boolean;
}

export interface Transaction {
  id: string;
  bookId: string;
  memberId: string;
  checkoutDate: string;
  dueDate: string;
  returnDate?: string;
  status: 'borrowed' | 'returned' | 'overdue';
  fine?: number;
  isShabbosCheckout?: boolean;
  depositAmount?: number;
  depositPaid?: number;
  depositRefunded?: number;
  paymentMethod?: 'cash' | 'credit-card';
  creditCardId?: string;
  returnDeadline?: string;
  depositReduction?: number;
}

export interface DashboardStats {
  totalBooks: number;
  totalMembers: number;
  booksCheckedOut: number;
  overdueBooks: number;
  availableBooks: number;
  activeMembers: number;
  shabbosCheckouts?: number;
  totalDepositsHeld?: number;
  bannedMembers?: number;
}

export interface ShabbosRule {
  category: ShabbosCategory;
  depositRange: [number, number];
  maxPerWeek: number;
  description: string;
}

export interface AdminSettings {
  adminCode: string;
  libraryName: string;
  allowGuestCheckout: boolean;
  defaultLoanPeriod: number;
  lateFeePerDay: number;
  maxBooksPerMember: number;
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  action: string;
  performedBy: string;
  targetUser?: string;
  details: string;
}

export const SHABBOS_RULES: Record<ShabbosCategory, ShabbosRule> = {
  'comic-book': {
    category: 'comic-book',
    depositRange: [5, 5],
    maxPerWeek: 1,
    description: 'Comic Books'
  },
  'gedolim': {
    category: 'gedolim',
    depositRange: [3, 3],
    maxPerWeek: 2,
    description: 'Gedolim Biographies'
  },
  'inspirational': {
    category: 'inspirational',
    depositRange: [1, 3],
    maxPerWeek: 1,
    description: 'Inspirational Stories'
  },
  'torah': {
    category: 'torah',
    depositRange: [4, 6],
    maxPerWeek: 999,
    description: 'Torah & Texts'
  },
  'jewish-history': {
    category: 'jewish-history',
    depositRange: [1, 3],
    maxPerWeek: 1,
    description: 'Jewish History'
  },
  'regular': {
    category: 'regular',
    depositRange: [0, 0],
    maxPerWeek: 999,
    description: 'Regular Books'
  }
};