import { useRef } from 'react';
import { X, Download, Printer } from 'lucide-react';
import { Member } from '../types';
import { generateBarcodeImage } from '../lib/barcode-generator';

interface UserCardDialogProps {
  member: Member;
  onClose: () => void;
}

export function UserCardDialog({ member, onClose }: UserCardDialogProps) {
  const cardRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    window.print();
  };

  const handleDownload = () => {
    // Simple download as image would require html2canvas library
    // For now, just print
    handlePrint();
  };

  const barcodeImage = member.cardBarcode ? generateBarcodeImage(member.cardBarcode) : '';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full">
        <div className="border-b border-gray-200 p-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold">Library Member Card</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {/* Card Preview */}
          <div 
            ref={cardRef}
            className="bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl shadow-lg p-6 text-white mx-auto"
            style={{ width: '400px', height: '250px' }}
          >
            <div className="flex flex-col h-full justify-between">
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center">
                    <span className="text-blue-600 font-bold text-lg">L</span>
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">LibraryOS</h3>
                    <p className="text-xs text-blue-200">Member Card</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <div>
                    <p className="text-xs text-blue-200">Member Name</p>
                    <p className="font-semibold text-lg">{member.name}</p>
                  </div>
                  <div>
                    <p className="text-xs text-blue-200">Membership ID</p>
                    <p className="font-mono font-semibold">{member.membershipId}</p>
                  </div>
                </div>
              </div>

              {barcodeImage && (
                <div className="bg-white rounded p-2">
                  <img src={barcodeImage} alt="Member Barcode" className="w-full" />
                </div>
              )}
            </div>
          </div>

          {/* Member Info */}
          <div className="mt-6 bg-gray-50 rounded-lg p-4 space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Email:</span>
              <span className="font-medium">{member.email}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Phone:</span>
              <span className="font-medium">{member.phone}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Status:</span>
              <span className={`font-medium ${
                member.status === 'active' ? 'text-green-600' : 'text-gray-600'
              }`}>
                {member.status.charAt(0).toUpperCase() + member.status.slice(1)}
              </span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Member Since:</span>
              <span className="font-medium">{new Date(member.joinDate).toLocaleDateString()}</span>
            </div>
          </div>

          {/* Actions */}
          <div className="mt-6 flex gap-3">
            <button
              onClick={handlePrint}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
            >
              <Printer className="w-4 h-4" />
              Print Card
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Close
            </button>
          </div>

          <p className="text-xs text-gray-500 text-center mt-4">
            💡 Tip: Use high-quality card stock paper for best results
          </p>
        </div>
      </div>

      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          ${cardRef.current ? `
          .print-card, .print-card * {
            visibility: visible;
          }
          .print-card {
            position: absolute;
            left: 0;
            top: 0;
          }` : ''}
        }
      `}</style>
    </div>
  );
}
