import { useState } from 'react';
import { X, Lock, Shield } from 'lucide-react';
import { verifyAdminCode } from '../lib/admin';

interface AdminLoginDialogProps {
  onSuccess: () => void;
  onClose: () => void;
}

export function AdminLoginDialog({ onSuccess, onClose }: AdminLoginDialogProps) {
  const [code, setCode] = useState('');
  const [error, setError] = useState('');
  const [attempts, setAttempts] = useState(0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (verifyAdminCode(code)) {
      onSuccess();
      onClose();
    } else {
      setError('Invalid admin code');
      setAttempts(prev => prev + 1);
      setCode('');
      
      if (attempts >= 2) {
        setTimeout(() => {
          setError('Too many failed attempts. Please try again later.');
        }, 100);
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="border-b border-gray-200 p-4 flex items-center justify-between bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
          <div className="flex items-center gap-2">
            <Shield className="w-6 h-6" />
            <h2 className="text-xl font-semibold">Admin Access</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-blue-700 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center">
            <Lock className="w-12 h-12 text-blue-600 mx-auto mb-2" />
            <p className="text-sm text-blue-800">
              This section requires administrator privileges.
            </p>
            <p className="text-xs text-blue-600 mt-1">
              Default code: 1234
            </p>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-800">
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Enter Admin Code
            </label>
            <input
              type="password"
              required
              value={code}
              onChange={(e) => {
                setCode(e.target.value);
                setError('');
              }}
              placeholder="Enter code..."
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-center text-lg font-mono"
              maxLength={10}
              autoFocus
            />
          </div>

          <div className="flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={attempts >= 3}
              className={`flex-1 px-4 py-2 rounded-lg transition-colors font-semibold ${
                attempts >= 3
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              Access Admin
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
