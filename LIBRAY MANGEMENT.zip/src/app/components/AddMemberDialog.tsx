import { useState } from 'react';
import { X, RefreshCw, Hash, Barcode } from 'lucide-react';
import { Member } from '../types';
import { generateUserBarcode } from '../lib/barcode-generator';
import { generateUniquePIN } from '../lib/pin-generator';
import { getMembers } from '../lib/storage';

interface AddMemberDialogProps {
  member?: Member;
  onSave: (member: Omit<Member, 'id'>) => void;
  onClose: () => void;
}

export function AddMemberDialog({ member, onSave, onClose }: AddMemberDialogProps) {
  const existingMembers = getMembers();
  const existingPINs = existingMembers.map(m => m.memberPIN).filter(Boolean) as string[];
  
  const [formData, setFormData] = useState({
    name: member?.name || '',
    email: member?.email || '',
    phone: member?.phone || '',
    membershipId: member?.membershipId || `MEM${Date.now().toString().slice(-6)}`,
    status: member?.status || 'active' as const,
    cardBarcode: member?.cardBarcode || '',
    memberPIN: member?.memberPIN || '',
  });

  const handleGenerateBarcode = () => {
    const barcode = generateUserBarcode(formData.membershipId);
    setFormData(prev => ({ ...prev, cardBarcode: barcode }));
  };

  const handleGeneratePIN = () => {
    const pin = generateUniquePIN(existingPINs);
    setFormData(prev => ({ ...prev, memberPIN: pin }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...formData,
      joinDate: member?.joinDate || new Date().toISOString(),
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="border-b border-gray-200 p-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold">
            {member ? 'Edit Member' : 'Add New Member'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Full Name
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="John Doe"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Email
            </label>
            <input
              type="email"
              required
              value={formData.email}
              onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="john@example.com"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Phone
            </label>
            <input
              type="tel"
              required
              value={formData.phone}
              onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="555-0123"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Membership ID
            </label>
            <input
              type="text"
              required
              value={formData.membershipId}
              onChange={(e) => setFormData(prev => ({ ...prev, membershipId: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="MEM001"
            />
          </div>

          {/* Barcode Generation */}
          <div className="border-t border-gray-200 pt-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Member Card Barcode (Optional)
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={formData.cardBarcode}
                onChange={(e) => setFormData(prev => ({ ...prev, cardBarcode: e.target.value }))}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
                placeholder="Auto-generated barcode"
                readOnly
              />
              <button
                type="button"
                onClick={handleGenerateBarcode}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <Barcode className="w-4 h-4" />
                Generate
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              Generate a unique barcode for member card scanning
            </p>
          </div>

          {/* PIN Generation */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Member PIN (Optional)
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={formData.memberPIN}
                onChange={(e) => setFormData(prev => ({ 
                  ...prev, 
                  memberPIN: e.target.value.replace(/\D/g, '').slice(0, 4) 
                }))}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent font-mono text-lg text-center tracking-widest"
                placeholder="****"
                maxLength={4}
              />
              <button
                type="button"
                onClick={handleGeneratePIN}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors flex items-center gap-2"
              >
                <Hash className="w-4 h-4" />
                Generate
              </button>
            </div>
            <p className="text-xs text-gray-500 mt-1">
              4-digit PIN for quick member identification at checkout
            </p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Status
            </label>
            <select
              value={formData.status}
              onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value as Member['status'] }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
              <option value="suspended">Suspended</option>
            </select>
          </div>

          <div className="flex gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              {member ? 'Update Member' : 'Add Member'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}