import { useState } from 'react';
import { X, AlertTriangle } from 'lucide-react';
import { Member, BanInfo } from '../types';

interface BanMemberDialogProps {
  member: Member;
  onBan: (banInfo: BanInfo) => void;
  onClose: () => void;
}

export function BanMemberDialog({ member, onBan, onClose }: BanMemberDialogProps) {
  const [reason, setReason] = useState('');
  const [notes, setNotes] = useState('');
  const [isPermanent, setIsPermanent] = useState(false);
  const [unbanDate, setUnbanDate] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const banInfo: BanInfo = {
      bannedDate: new Date().toISOString(),
      bannedBy: 'Admin',
      reason,
      notes: notes || undefined,
      isPermanent,
      unbanDate: !isPermanent && unbanDate ? new Date(unbanDate).toISOString() : undefined,
    };

    onBan(banInfo);
  };

  const minDate = new Date();
  minDate.setDate(minDate.getDate() + 1);
  const minDateStr = minDate.toISOString().split('T')[0];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
        <div className="border-b border-gray-200 p-4 flex items-center justify-between bg-red-600 text-white">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5" />
            <h2 className="text-xl font-semibold">Ban Member</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-red-700 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
            <p className="text-sm text-yellow-800">
              <strong>Warning:</strong> Banning {member.name} will prevent them from checking out any books. 
              They will see a ban alert when their card is scanned.
            </p>
          </div>

          <div className="bg-gray-50 rounded-lg p-3">
            <p className="text-sm text-gray-600">Member:</p>
            <p className="font-semibold text-gray-900">{member.name}</p>
            <p className="text-sm text-gray-600 mt-1">{member.membershipId}</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Ban Reason *
            </label>
            <select
              required
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            >
              <option value="">Select a reason...</option>
              <option value="Lost/Damaged Books">Lost or Damaged Books</option>
              <option value="Unpaid Fines">Unpaid Fines</option>
              <option value="Repeated Late Returns">Repeated Late Returns</option>
              <option value="Inappropriate Behavior">Inappropriate Behavior</option>
              <option value="Theft">Theft/Stealing</option>
              <option value="Violation of Library Rules">Violation of Library Rules</option>
              <option value="Other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Additional Notes
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              placeholder="Add any additional details about the ban..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
            />
          </div>

          <div className="border-t border-gray-200 pt-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isPermanent}
                onChange={(e) => {
                  setIsPermanent(e.target.checked);
                  if (e.target.checked) setUnbanDate('');
                }}
                className="w-4 h-4 text-red-600 rounded focus:ring-2 focus:ring-red-500"
              />
              <span className="text-sm font-medium text-gray-700">Permanent Ban</span>
            </label>
          </div>

          {!isPermanent && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Unban Date (Optional)
              </label>
              <input
                type="date"
                value={unbanDate}
                min={minDateStr}
                onChange={(e) => setUnbanDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              />
              <p className="text-xs text-gray-500 mt-1">
                Leave empty for manual unban only
              </p>
            </div>
          )}

          <div className="flex gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors font-semibold"
            >
              Ban Member
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
