import { Printer } from 'lucide-react';

interface PrintReportProps {
  title: string;
  onPrint: () => void;
}

export function PrintReport({ title, onPrint }: PrintReportProps) {
  const handlePrint = () => {
    onPrint();
    setTimeout(() => {
      window.print();
    }, 100);
  };

  return (
    <button
      onClick={handlePrint}
      className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors flex items-center gap-2"
    >
      <Printer className="w-4 h-4" />
      Print {title}
    </button>
  );
}
