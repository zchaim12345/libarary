import { AlertTriangle, X } from 'lucide-react';
import { Member } from '../types';

interface BannedAlertProps {
  member: Member;
  onClose: () => void;
}

export function BannedAlert({ member, onClose }: BannedAlertProps) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 z-50 flex items-center justify-center p-4 animate-pulse">
      <div className="bg-gradient-to-br from-red-600 to-red-800 rounded-lg shadow-2xl max-w-md w-full border-4 border-red-400">
        <div className="p-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="bg-white rounded-full p-3 animate-bounce">
                <AlertTriangle className="w-8 h-8 text-red-600" />
              </div>
              <h2 className="text-2xl font-bold">BANNED USER</h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-red-700 rounded-lg transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="bg-white bg-opacity-20 rounded-lg p-4 mb-4">
            <div className="space-y-2">
              <div>
                <p className="text-sm text-red-100">Member Name:</p>
                <p className="text-xl font-semibold">{member.name}</p>
              </div>
              <div>
                <p className="text-sm text-red-100">Membership ID:</p>
                <p className="font-mono font-semibold">{member.membershipId}</p>
              </div>
              <div>
                <p className="text-sm text-red-100">Barcode:</p>
                <p className="font-mono text-sm">{member.cardBarcode}</p>
              </div>
            </div>
          </div>

          {member.banInfo && (
            <div className="bg-red-900 bg-opacity-50 rounded-lg p-4 mb-4">
              <h3 className="font-semibold mb-2">Ban Information</h3>
              <div className="space-y-1 text-sm">
                <p><strong>Reason:</strong> {member.banInfo.reason}</p>
                {member.banInfo.notes && (
                  <p><strong>Notes:</strong> {member.banInfo.notes}</p>
                )}
                <p><strong>Banned Date:</strong> {new Date(member.banInfo.bannedDate).toLocaleDateString()}</p>
                <p><strong>Type:</strong> {member.banInfo.isPermanent ? 'Permanent' : 'Temporary'}</p>
                {member.banInfo.unbanDate && !member.banInfo.isPermanent && (
                  <p><strong>Unban Date:</strong> {new Date(member.banInfo.unbanDate).toLocaleDateString()}</p>
                )}
              </div>
            </div>
          )}

          <div className="bg-yellow-500 text-yellow-900 rounded-lg p-3 text-center font-semibold">
            ⚠️ THIS USER IS NOT ALLOWED TO CHECK OUT BOOKS ⚠️
          </div>

          <button
            onClick={onClose}
            className="w-full mt-4 px-4 py-3 bg-white text-red-600 rounded-lg hover:bg-red-50 transition-colors font-semibold"
          >
            Close Alert
          </button>
        </div>
      </div>
    </div>
  );
}
