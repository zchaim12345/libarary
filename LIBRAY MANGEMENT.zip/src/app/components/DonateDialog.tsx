import { useState } from 'react';
import { X, Heart, CreditCard, DollarSign, QrCode } from 'lucide-react';
import { toast } from 'sonner';

interface DonateDialogProps {
  onClose: () => void;
}

export function DonateDialog({ onClose }: DonateDialogProps) {
  const [amount, setAmount] = useState('');
  const [customAmount, setCustomAmount] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'cash' | 'check'>('card');
  const [donorName, setDonorName] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);
  const [message, setMessage] = useState('');

  const presetAmounts = [18, 36, 54, 100, 180, 360, 500, 1000];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const finalAmount = amount === 'custom' ? customAmount : amount;
    
    // Store donation record
    const donation = {
      id: Date.now().toString(),
      amount: parseFloat(finalAmount),
      donorName: isAnonymous ? 'Anonymous' : donorName,
      paymentMethod,
      message,
      date: new Date().toISOString(),
    };

    const donations = JSON.parse(localStorage.getItem('library_donations') || '[]');
    donations.push(donation);
    localStorage.setItem('library_donations', JSON.stringify(donations));

    toast.success(`Thank you for your donation of $${parseFloat(finalAmount).toFixed(2)}!`);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="border-b border-gray-200 p-6 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Heart className="w-8 h-8 fill-current" />
              <div>
                <h2 className="text-2xl font-semibold">Support Zichron Chaim Library</h2>
                <p className="text-sm text-purple-100 mt-1">Help us continue our mission</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-purple-700 rounded-lg transition-colors">
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Mission Statement */}
          <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6 border border-purple-200">
            <h3 className="font-semibold text-lg text-gray-900 mb-2">Our Mission</h3>
            <p className="text-gray-700 text-sm leading-relaxed">
              Zichron Chaim Library is dedicated to providing access to Torah literature, 
              Jewish books, and educational materials for our community. Your generous donation 
              helps us expand our collection, maintain our facilities, and serve more families.
            </p>
            <div className="mt-4 grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-2xl font-bold text-purple-600">500+</p>
                <p className="text-xs text-gray-600">Books Available</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-blue-600">200+</p>
                <p className="text-xs text-gray-600">Active Members</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-green-600">100%</p>
                <p className="text-xs text-gray-600">Community Funded</p>
              </div>
            </div>
          </div>

          {/* Preset Amounts */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Select Donation Amount (Chai multiples available)
            </label>
            <div className="grid grid-cols-4 gap-3">
              {presetAmounts.map((amt) => (
                <button
                  key={amt}
                  type="button"
                  onClick={() => setAmount(amt.toString())}
                  className={`p-3 rounded-lg border-2 transition-all ${
                    amount === amt.toString()
                      ? 'border-purple-500 bg-purple-50 text-purple-700'
                      : 'border-gray-300 hover:border-purple-300'
                  }`}
                >
                  <p className="font-semibold">${amt}</p>
                  {amt % 18 === 0 && <p className="text-xs text-gray-500">({amt / 18} Chai)</p>}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={() => setAmount('custom')}
              className={`mt-3 w-full p-3 rounded-lg border-2 transition-all ${
                amount === 'custom'
                  ? 'border-purple-500 bg-purple-50 text-purple-700'
                  : 'border-gray-300 hover:border-purple-300'
              }`}
            >
              Custom Amount
            </button>
          </div>

          {/* Custom Amount */}
          {amount === 'custom' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Enter Amount
              </label>
              <div className="relative">
                <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                <input
                  type="number"
                  required
                  min="1"
                  step="0.01"
                  value={customAmount}
                  onChange={(e) => setCustomAmount(e.target.value)}
                  className="w-full pl-8 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="0.00"
                />
              </div>
            </div>
          )}

          {/* Payment Method */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
            <div className="grid grid-cols-3 gap-3">
              <button
                type="button"
                onClick={() => setPaymentMethod('card')}
                className={`p-4 rounded-lg border-2 transition-all ${
                  paymentMethod === 'card'
                    ? 'border-purple-500 bg-purple-50'
                    : 'border-gray-300 hover:border-purple-300'
                }`}
              >
                <CreditCard className="w-6 h-6 mx-auto mb-1 text-purple-600" />
                <p className="text-sm font-medium">Credit Card</p>
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('cash')}
                className={`p-4 rounded-lg border-2 transition-all ${
                  paymentMethod === 'cash'
                    ? 'border-green-500 bg-green-50'
                    : 'border-gray-300 hover:border-green-300'
                }`}
              >
                <DollarSign className="w-6 h-6 mx-auto mb-1 text-green-600" />
                <p className="text-sm font-medium">Cash</p>
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('check')}
                className={`p-4 rounded-lg border-2 transition-all ${
                  paymentMethod === 'check'
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-300 hover:border-blue-300'
                }`}
              >
                <QrCode className="w-6 h-6 mx-auto mb-1 text-blue-600" />
                <p className="text-sm font-medium">Check</p>
              </button>
            </div>
          </div>

          {/* Donor Information */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="anonymous"
                checked={isAnonymous}
                onChange={(e) => setIsAnonymous(e.target.checked)}
                className="w-4 h-4 text-purple-600 rounded focus:ring-2 focus:ring-purple-500"
              />
              <label htmlFor="anonymous" className="text-sm text-gray-700">
                Make this donation anonymous
              </label>
            </div>

            {!isAnonymous && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Your Name (for recognition)
                </label>
                <input
                  type="text"
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  placeholder="Enter your name"
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Message (Optional)
              </label>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Add a dedication or message..."
              />
            </div>
          </div>

          {/* Tax Deductible Notice */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              💙 <strong>Tax Deductible:</strong> Zichron Chaim Library is a registered 501(c)(3) 
              organization. Your donation may be tax-deductible. Please consult your tax advisor.
            </p>
          </div>

          {/* Dedication Options */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <h4 className="font-semibold text-yellow-900 mb-2">📖 Dedication Opportunities</h4>
            <ul className="text-sm text-yellow-800 space-y-1">
              <li>• $180+ Dedicate a book in memory or honor of a loved one</li>
              <li>• $360+ Sponsor a shelf in the library</li>
              <li>• $1,000+ Name a section or category</li>
              <li>• Contact us for custom dedication options</li>
            </ul>
          </div>

          {/* Submit */}
          <div className="flex gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!amount || (amount === 'custom' && !customAmount)}
              className={`flex-1 px-4 py-3 rounded-lg transition-colors font-semibold ${
                !amount || (amount === 'custom' && !customAmount)
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700'
              }`}
            >
              Complete Donation
            </button>
          </div>

          <p className="text-xs text-gray-500 text-center">
            By donating, you agree to our terms and conditions. All donations are final and non-refundable.
          </p>
        </form>
      </div>
    </div>
  );
}
