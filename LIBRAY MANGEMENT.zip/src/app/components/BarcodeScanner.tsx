import { useEffect, useRef, useState } from 'react';
import { BrowserMultiFormatReader, NotFoundException } from '@zxing/library';
import { Camera, X } from 'lucide-react';

interface BarcodeScannerProps {
  onScan: (code: string) => void;
  onClose: () => void;
}

export function BarcodeScanner({ onScan, onClose }: BarcodeScannerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [error, setError] = useState<string>('');
  const readerRef = useRef<BrowserMultiFormatReader | null>(null);

  useEffect(() => {
    const reader = new BrowserMultiFormatReader();
    readerRef.current = reader;

    const startScanning = async () => {
      try {
        setIsScanning(true);
        setError('');

        const videoInputDevices = await reader.listVideoInputDevices();
        
        if (videoInputDevices.length === 0) {
          setError('No camera found. Please connect a camera and try again.');
          return;
        }

        // Use the first available camera
        const selectedDeviceId = videoInputDevices[0].deviceId;

        await reader.decodeFromVideoDevice(
          selectedDeviceId,
          videoRef.current!,
          (result, err) => {
            if (result) {
              const code = result.getText();
              onScan(code);
            }
            if (err && !(err instanceof NotFoundException)) {
              console.error('Scanning error:', err);
            }
          }
        );
      } catch (err) {
        console.error('Scanner initialization error:', err);
        setError('Failed to access camera. Please grant camera permissions.');
        setIsScanning(false);
      }
    };

    startScanning();

    return () => {
      reader.reset();
    };
  }, [onScan]);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center">
      <div className="relative w-full max-w-2xl mx-4">
        <button
          onClick={onClose}
          className="absolute -top-12 right-0 text-white hover:text-gray-300 transition-colors"
        >
          <X className="w-8 h-8" />
        </button>

        <div className="bg-white rounded-lg overflow-hidden">
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-4 flex items-center gap-3">
            <Camera className="w-6 h-6" />
            <div>
              <h2 className="font-semibold">Scan Book Barcode</h2>
              <p className="text-sm text-blue-100">Position the barcode within the frame</p>
            </div>
          </div>

          <div className="relative aspect-video bg-black">
            <video
              ref={videoRef}
              className="w-full h-full object-cover"
              autoPlay
              playsInline
            />
            
            {/* Scanning overlay */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
              <div className="w-64 h-32 border-4 border-green-500 rounded-lg relative">
                <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-white"></div>
                <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-white"></div>
                <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-white"></div>
                <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-white"></div>
              </div>
            </div>

            {error && (
              <div className="absolute bottom-0 left-0 right-0 bg-red-500 text-white p-4 text-center">
                {error}
              </div>
            )}

            {isScanning && !error && (
              <div className="absolute bottom-0 left-0 right-0 bg-green-500 text-white p-2 text-center text-sm">
                Scanner ready - Point camera at barcode
              </div>
            )}
          </div>

          <div className="p-4 bg-gray-50 text-center text-sm text-gray-600">
            <p>The scanner will automatically detect barcodes. Hold the book steady and ensure good lighting.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
