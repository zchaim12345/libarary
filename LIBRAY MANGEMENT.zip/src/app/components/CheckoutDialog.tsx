import { useState } from 'react';
import { X, Scan, User } from 'lucide-react';
import { Book, Member } from '../types';
import { BarcodeScanner } from './BarcodeScanner';
import { MemberIdentificationDialog } from './MemberIdentificationDialog';

interface CheckoutDialogProps {
  books: Book[];
  members: Member[];
  onCheckout: (bookId: string, memberId: string, dueDate: string) => void;
  onClose: () => void;
}

export function CheckoutDialog({ books, members, onCheckout, onClose }: CheckoutDialogProps) {
  const [showScanner, setShowScanner] = useState(false);
  const [showMemberDialog, setShowMemberDialog] = useState(false);
  const [selectedBookId, setSelectedBookId] = useState('');
  const [selectedMemberId, setSelectedMemberId] = useState('');
  const [dueDate, setDueDate] = useState(() => {
    const date = new Date();
    date.setDate(date.getDate() + 14); // Default 14 days
    return date.toISOString().split('T')[0];
  });

  const availableBooks = books.filter(b => b.availableCopies > 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedBookId && selectedMemberId) {
      onCheckout(selectedBookId, selectedMemberId, dueDate);
    }
  };

  const handleScan = (code: string) => {
    const book = books.find(b => b.isbn === code);
    if (book) {
      setSelectedBookId(book.id);
      setShowScanner(false);
    } else {
      alert('Book not found with this barcode');
    }
  };

  const handleMemberSelect = (memberId: string) => {
    setSelectedMemberId(memberId);
    setShowMemberDialog(false);
  };

  const selectedMember = members.find(m => m.id === selectedMemberId);

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
          <div className="border-b border-gray-200 p-4 flex items-center justify-between">
            <h2 className="text-xl font-semibold">Check Out Book</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Select Book
              </label>
              <div className="flex gap-2">
                <select
                  required
                  value={selectedBookId}
                  onChange={(e) => setSelectedBookId(e.target.value)}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Choose a book...</option>
                  {availableBooks.map(book => (
                    <option key={book.id} value={book.id}>
                      {book.title} - {book.author} ({book.availableCopies} available)
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => setShowScanner(true)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  title="Scan barcode"
                >
                  <Scan className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Select Member
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={selectedMember ? `${selectedMember.name} (${selectedMember.membershipId})` : ''}
                  readOnly
                  placeholder="Click to identify member..."
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg bg-gray-50 cursor-pointer"
                  onClick={() => setShowMemberDialog(true)}
                />
                <button
                  type="button"
                  onClick={() => setShowMemberDialog(true)}
                  className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                  title="Identify member"
                >
                  <User className="w-4 h-4" />
                </button>
              </div>
              {selectedMember?.memberPIN && (
                <p className="text-xs text-gray-500 mt-1">
                  Member PIN: {selectedMember.memberPIN}
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Due Date
              </label>
              <input
                type="date"
                required
                value={dueDate}
                min={new Date().toISOString().split('T')[0]}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div className="flex gap-3 pt-4 border-t border-gray-200">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Check Out
              </button>
            </div>
          </form>
        </div>
      </div>

      {showScanner && (
        <BarcodeScanner
          onScan={handleScan}
          onClose={() => setShowScanner(false)}
        />
      )}

      {showMemberDialog && (
        <MemberIdentificationDialog
          members={members}
          onSelect={handleMemberSelect}
          onClose={() => setShowMemberDialog(false)}
          title="Identify Member for Checkout"
        />
      )}
    </>
  );
}