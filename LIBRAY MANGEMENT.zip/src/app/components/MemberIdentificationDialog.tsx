import { useState } from 'react';
import { X, Scan, Hash, User } from 'lucide-react';
import { Member } from '../types';
import { BarcodeScanner } from './BarcodeScanner';
import { validatePIN } from '../lib/pin-generator';

interface MemberIdentificationDialogProps {
  members: Member[];
  onSelect: (memberId: string) => void;
  onClose: () => void;
  title?: string;
}

export function MemberIdentificationDialog({ 
  members, 
  onSelect, 
  onClose,
  title = "Identify Member" 
}: MemberIdentificationDialogProps) {
  const [method, setMethod] = useState<'scan' | 'pin' | 'select'>('select');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [showScanner, setShowScanner] = useState(false);

  const handlePINSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validatePIN(pin)) {
      setError('PIN must be 4 digits');
      return;
    }

    const member = members.find(m => m.memberPIN === pin);
    if (member) {
      if (member.status === 'banned') {
        setError('This member is BANNED');
        return;
      }
      onSelect(member.id);
    } else {
      setError('Invalid PIN - Member not found');
      setPin('');
    }
  };

  const handleScan = (code: string) => {
    const member = members.find(m => m.cardBarcode === code || m.membershipId === code);
    if (member) {
      if (member.status === 'banned') {
        setError('This member is BANNED');
        setShowScanner(false);
        return;
      }
      onSelect(member.id);
    } else {
      setError('Member not found with this barcode');
    }
    setShowScanner(false);
  };

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
          <div className="border-b border-gray-200 p-4 flex items-center justify-between">
            <h2 className="text-xl font-semibold">{title}</h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-6 space-y-4">
            {/* Method Selection */}
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => {
                  setMethod('scan');
                  setError('');
                  setShowScanner(true);
                }}
                className={`p-3 border-2 rounded-lg transition-all ${
                  method === 'scan'
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-blue-300'
                }`}
              >
                <Scan className="w-6 h-6 mx-auto text-blue-600 mb-1" />
                <p className="text-xs font-medium">Scan Card</p>
              </button>

              <button
                onClick={() => {
                  setMethod('pin');
                  setError('');
                  setPin('');
                }}
                className={`p-3 border-2 rounded-lg transition-all ${
                  method === 'pin'
                    ? 'border-green-500 bg-green-50'
                    : 'border-gray-200 hover:border-green-300'
                }`}
              >
                <Hash className="w-6 h-6 mx-auto text-green-600 mb-1" />
                <p className="text-xs font-medium">Enter PIN</p>
              </button>

              <button
                onClick={() => {
                  setMethod('select');
                  setError('');
                }}
                className={`p-3 border-2 rounded-lg transition-all ${
                  method === 'select'
                    ? 'border-purple-500 bg-purple-50'
                    : 'border-gray-200 hover:border-purple-300'
                }`}
              >
                <User className="w-6 h-6 mx-auto text-purple-600 mb-1" />
                <p className="text-xs font-medium">Select</p>
              </button>
            </div>

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-800">
                {error}
              </div>
            )}

            {/* PIN Entry */}
            {method === 'pin' && (
              <form onSubmit={handlePINSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Enter 4-Digit PIN
                  </label>
                  <input
                    type="tel"
                    value={pin}
                    onChange={(e) => {
                      const value = e.target.value.replace(/\D/g, '').slice(0, 4);
                      setPin(value);
                      setError('');
                    }}
                    placeholder="****"
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent text-center text-2xl font-mono tracking-widest"
                    maxLength={4}
                    autoFocus
                  />
                </div>
                <button
                  type="submit"
                  disabled={pin.length !== 4}
                  className={`w-full px-4 py-3 rounded-lg transition-colors font-semibold ${
                    pin.length === 4
                      ? 'bg-green-600 text-white hover:bg-green-700'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  Submit PIN
                </button>
              </form>
            )}

            {/* Manual Selection */}
            {method === 'select' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Select Member
                </label>
                <select
                  onChange={(e) => {
                    if (e.target.value) {
                      onSelect(e.target.value);
                    }
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                >
                  <option value="">Choose a member...</option>
                  {members.filter(m => m.status === 'active').map(member => (
                    <option key={member.id} value={member.id}>
                      {member.name} ({member.membershipId})
                      {member.memberPIN && ` - PIN: ${member.memberPIN}`}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {method === 'scan' && !showScanner && (
              <div className="text-center py-8">
                <Scan className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Click to activate scanner</p>
                <button
                  onClick={() => setShowScanner(true)}
                  className="mt-4 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Activate Scanner
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {showScanner && (
        <BarcodeScanner
          onScan={handleScan}
          onClose={() => {
            setShowScanner(false);
            setMethod('select');
          }}
        />
      )}
    </>
  );
}
