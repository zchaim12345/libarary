import { useState } from 'react';
import { X, Upload, FileText, Download } from 'lucide-react';
import { 
  generateBorrowingFormPDF, 
  generateReturnFormPDF, 
  generateShabbosFormPDF,
  generateMemberApplicationPDF,
  generateBookAdditionPDF
} from '../lib/form-processor';

interface FormUploadDialogProps {
  formType: 'borrowing' | 'return' | 'shabbos' | 'member' | 'book';
  onProcess: (data: any) => void;
  onClose: () => void;
}

export function FormUploadDialog({ formType, onProcess, onClose }: FormUploadDialogProps) {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [manualEntry, setManualEntry] = useState(false);

  const formTitles = {
    borrowing: 'Borrowing Form',
    return: 'Return Form',
    shabbos: 'Shabbos Learning Form',
    member: 'Member Application',
    book: 'Book Addition Form',
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setSelectedImage(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProcessForm = async () => {
    setIsProcessing(true);
    
    // Simulate processing delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // For now, open manual entry form
    setManualEntry(true);
    setIsProcessing(false);
  };

  const handleDownloadPDF = () => {
    let pdfContent = '';
    let filename = '';

    switch (formType) {
      case 'borrowing':
        pdfContent = generateBorrowingFormPDF();
        filename = 'Borrowing_Form.txt';
        break;
      case 'return':
        pdfContent = generateReturnFormPDF();
        filename = 'Return_Form.txt';
        break;
      case 'shabbos':
        pdfContent = generateShabbosFormPDF();
        filename = 'Shabbos_Learning_Form.txt';
        break;
      case 'member':
        pdfContent = generateMemberApplicationPDF();
        filename = 'Member_Application.txt';
        break;
      case 'book':
        pdfContent = generateBookAdditionPDF();
        filename = 'Book_Addition_Form.txt';
        break;
    }

    const blob = new Blob([pdfContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="border-b border-gray-200 p-4 flex items-center justify-between bg-gradient-to-r from-purple-600 to-indigo-600 text-white">
          <div>
            <h2 className="text-xl font-semibold">Process {formTitles[formType]}</h2>
            <p className="text-sm text-purple-100">Upload filled form or enter manually</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-purple-700 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Download Template */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <h3 className="font-medium text-blue-900 mb-1">Need a blank form?</h3>
                <p className="text-sm text-blue-700">Download the template, print it, fill it out, and upload a photo</p>
              </div>
              <button
                onClick={handleDownloadPDF}
                className="ml-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Download Form
              </button>
            </div>
          </div>

          {!manualEntry ? (
            <>
              {/* Upload Section */}
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                {selectedImage ? (
                  <div className="space-y-4">
                    <img src={selectedImage} alt="Uploaded form" className="max-h-64 mx-auto rounded border border-gray-300" />
                    <div className="flex gap-2 justify-center">
                      <button
                        onClick={handleProcessForm}
                        disabled={isProcessing}
                        className={`px-6 py-3 rounded-lg transition-colors font-semibold ${
                          isProcessing
                            ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                            : 'bg-green-600 text-white hover:bg-green-700'
                        }`}
                      >
                        {isProcessing ? 'Processing...' : 'Process Form'}
                      </button>
                      <button
                        onClick={() => setSelectedImage(null)}
                        className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ) : (
                  <label className="cursor-pointer">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                    <div className="space-y-3">
                      <Upload className="w-16 h-16 text-gray-400 mx-auto" />
                      <div>
                        <p className="text-lg font-medium text-gray-900">Upload Filled Form</p>
                        <p className="text-sm text-gray-500 mt-1">Click to browse or drag and drop</p>
                        <p className="text-xs text-gray-400 mt-1">Supports: JPG, PNG, PDF</p>
                      </div>
                    </div>
                  </label>
                )}
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-300"></div>
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-2 bg-white text-gray-500">OR</span>
                </div>
              </div>

              <button
                onClick={() => setManualEntry(true)}
                className="w-full px-4 py-3 border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
              >
                <FileText className="w-5 h-5" />
                Enter Information Manually
              </button>
            </>
          ) : (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 text-center">
              <FileText className="w-12 h-12 text-yellow-600 mx-auto mb-3" />
              <p className="text-yellow-900 font-medium">Manual Entry Mode</p>
              <p className="text-sm text-yellow-700 mt-1">
                Form processing will extract data. For now, you can add {formType} manually through the respective section.
              </p>
              <button
                onClick={onClose}
                className="mt-4 px-4 py-2 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700 transition-colors"
              >
                Close & Add Manually
              </button>
            </div>
          )}

          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="font-medium text-gray-900 mb-2">📋 How It Works</h3>
            <ol className="text-sm text-gray-600 space-y-1 list-decimal list-inside">
              <li>Download the blank form template</li>
              <li>Print and fill out the form by hand</li>
              <li>Take a clear photo or scan the form</li>
              <li>Upload the image here</li>
              <li>System will extract data automatically (OCR)</li>
              <li>Review and confirm the extracted information</li>
            </ol>
            <p className="text-xs text-gray-500 mt-3">
              💡 Tip: Ensure good lighting and clear handwriting for best results
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
