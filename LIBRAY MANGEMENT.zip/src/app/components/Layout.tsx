import { Link, useLocation, useNavigate } from 'react-router';
import { 
  BookOpen, 
  Users, 
  ArrowLeftRight, 
  BarChart3, 
  LayoutDashboard,
  Menu,
  X,
  Settings,
  Star,
  IdCard,
  Shield,
  Heart
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { checkAdminSession, setAdminSession } from '../lib/admin';
import { AdminLoginDialog } from './AdminLoginDialog';
import { DonateDialog } from './DonateDialog';

export function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [showDonateDialog, setShowDonateDialog] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    setIsAdmin(checkAdminSession());
  }, [location]);

  const navItems = [
    { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/books', icon: BookOpen, label: 'Books' },
    { path: '/members', icon: Users, label: 'Members' },
    { path: '/transactions', icon: ArrowLeftRight, label: 'Transactions' },
    { path: '/shabbos', icon: Star, label: 'Shabbos Lending' },
    { path: '/user-profiles', icon: IdCard, label: 'User Profiles' },
    { path: '/reports', icon: BarChart3, label: 'Reports' },
    { path: '/donations', icon: Heart, label: 'Donations' },
    { path: '/settings', icon: Settings, label: 'Settings' },
  ];

  const handleAdminClick = () => {
    if (checkAdminSession()) {
      navigate('/admin');
    } else {
      setShowAdminLogin(true);
    }
  };

  const handleAdminLogin = () => {
    setAdminSession(true);
    setIsAdmin(true);
    navigate('/admin');
  };

  const isActive = (path: string) => {
    if (path === '/') {
      return location.pathname === '/';
    }
    return location.pathname.startsWith(path);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <BookOpen className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="font-semibold text-xl text-gray-900">Zichron Chaim Library</h1>
                <p className="text-xs text-gray-500">Smart Library Management</p>
              </div>
            </div>
            
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6 text-gray-600" />
              ) : (
                <Menu className="w-6 h-6 text-gray-600" />
              )}
            </button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar Navigation */}
        <nav 
          className={`
            fixed lg:sticky top-[73px] left-0 h-[calc(100vh-73px)] bg-white border-r border-gray-200
            w-64 transition-transform duration-300 z-30
            ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
          `}
        >
          <div className="p-4 space-y-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.path);
              
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={`
                    flex items-center gap-3 px-4 py-3 rounded-lg transition-colors
                    ${active 
                      ? 'bg-blue-50 text-blue-700 font-medium' 
                      : 'text-gray-700 hover:bg-gray-50'
                    }
                  `}
                >
                  <Icon className="w-5 h-5" />
                  <span>{item.label}</span>
                </Link>
              );
            })}

            {/* Admin Button */}
            <button
              onClick={handleAdminClick}
              className={`
                w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors
                ${isActive('/admin')
                  ? 'bg-red-50 text-red-700 font-medium' 
                  : 'text-red-600 hover:bg-red-50'
                }
              `}
            >
              <Shield className="w-5 h-5" />
              <span>Admin Panel</span>
              {!isAdmin && <span className="text-xs bg-red-100 px-2 py-0.5 rounded">🔒</span>}
            </button>
          </div>

          <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-200 space-y-2">
            <button
              onClick={() => setShowDonateDialog(true)}
              className="w-full p-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:from-purple-700 hover:to-pink-700 transition-all flex items-center justify-center gap-2 font-medium"
            >
              <Heart className="w-5 h-5 fill-current" />
              Donate Now
            </button>
            
            <div className="bg-blue-50 rounded-lg p-3">
              <p className="text-xs font-medium text-blue-900">
                {isAdmin ? '👑 Admin Mode Active' : 'Zichron Chaim Library'}
              </p>
              <p className="text-xs text-blue-700 mt-1">
                {isAdmin ? 'Full system access' : 'Logged in as User'}
              </p>
            </div>
          </div>
        </nav>

        {/* Mobile overlay */}
        {isMobileMenuOpen && (
          <div 
            className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
            onClick={() => setIsMobileMenuOpen(false)}
          />
        )}

        {/* Main Content */}
        <main className="flex-1 p-4 lg:p-6 max-w-7xl mx-auto w-full">
          {children}
        </main>
      </div>

      {showAdminLogin && (
        <AdminLoginDialog
          onSuccess={handleAdminLogin}
          onClose={() => setShowAdminLogin(false)}
        />
      )}

      {showDonateDialog && (
        <DonateDialog onClose={() => setShowDonateDialog(false)} />
      )}
    </div>
  );
}