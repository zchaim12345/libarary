import { useState, useEffect } from 'react';
import { X, CreditCard, DollarSign, AlertCircle, Calendar, Gift } from 'lucide-react';
import { Book, Member, ShabbosCategory, SHABBOS_RULES } from '../types';
import { isDepositRequired, getNextFriday, checkWeeklyLimit, getReturnDeadline, isShabbosCheckoutAllowed, getDayName } from '../lib/shabbos-logic';

interface ShabbosCheckoutDialogProps {
  book: Book;
  members: Member[];
  onCheckout: (memberId: string, paymentMethod: 'cash' | 'credit-card' | 'none', creditCardId?: string) => void;
  onClose: () => void;
}

export function ShabbosCheckoutDialog({ book, members, onCheckout, onClose }: ShabbosCheckoutDialogProps) {
  const [selectedMemberId, setSelectedMemberId] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'credit-card' | 'none'>('none');
  const [selectedCardId, setSelectedCardId] = useState('');
  const [canCheckout, setCanCheckout] = useState(true);
  const [limitMessage, setLimitMessage] = useState('');

  const selectedMember = members.find(m => m.id === selectedMemberId);
  const category = book.shabbosCategory || 'regular';
  const rule = SHABBOS_RULES[category];
  const depositAmount = book.depositAmount || rule.depositRange[0];
  const needsDeposit = isDepositRequired();
  const checkoutAllowed = isShabbosCheckoutAllowed();
  const today = getDayName();

  useEffect(() => {
    if (selectedMemberId && book.shabbosCategory) {
      const limit = checkWeeklyLimit(selectedMemberId, book.shabbosCategory);
      setCanCheckout(limit.allowed);
      if (!limit.allowed) {
        setLimitMessage(`Weekly limit reached: ${limit.current}/${limit.max} ${rule.description} this week`);
      } else {
        setLimitMessage(`${limit.current}/${limit.max} ${rule.description} borrowed this week`);
      }
    }
  }, [selectedMemberId, book.shabbosCategory]);

  // Set default payment method based on deposit requirement
  useEffect(() => {
    setPaymentMethod(needsDeposit ? 'cash' : 'none');
  }, [needsDeposit]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkoutAllowed) {
      alert('Shabbos checkouts are only available Sunday through Friday!');
      return;
    }
    if (!canCheckout) {
      alert(limitMessage);
      return;
    }
    onCheckout(selectedMemberId, paymentMethod, paymentMethod === 'credit-card' ? selectedCardId : undefined);
  };

  const returnDeadline = getReturnDeadline(new Date().toISOString());
  const deadlineDate = new Date(returnDeadline);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex items-center justify-center p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="border-b border-gray-200 p-4 flex items-center justify-between bg-blue-600 text-white">
          <div>
            <h2 className="text-xl font-semibold">Shabbos Checkout</h2>
            <p className="text-sm text-blue-100">Book Lending - {today}</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-blue-700 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {!checkoutAllowed && (
          <div className="bg-red-50 border border-red-200 p-4 m-4 rounded-lg">
            <div className="flex gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-medium text-red-900">Saturday Only - No Checkouts</p>
                <p className="text-sm text-red-700 mt-1">
                  Shabbos checkouts available Sunday through Friday only.
                </p>
              </div>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Book Info */}
          <div className="bg-blue-50 rounded-lg p-4">
            <h3 className="font-semibold text-gray-900">{book.title}</h3>
            <p className="text-sm text-gray-600 mt-1">{book.author}</p>
            <div className="mt-3 flex items-center justify-between">
              <span className="text-sm text-gray-600">Category:</span>
              <span className="font-medium text-blue-700">{rule.description}</span>
            </div>
            <div className="flex items-center justify-between mt-1">
              <span className="text-sm text-gray-600">Deposit:</span>
              {needsDeposit ? (
                <span className="font-semibold text-green-700">${depositAmount.toFixed(2)}</span>
              ) : (
                <span className="font-semibold text-blue-700 flex items-center gap-1">
                  <Gift className="w-4 h-4" />
                  FREE (No Deposit)
                </span>
              )}
            </div>
          </div>

          {/* Deposit Notice */}
          {!needsDeposit && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <div className="flex items-center gap-2 text-green-900 mb-1">
                <Gift className="w-4 h-4" />
                <span className="font-medium text-sm">No Deposit Required</span>
              </div>
              <p className="text-xs text-green-700">
                Sunday-Thursday checkouts are FREE with no deposit! Friday checkouts require deposit.
              </p>
            </div>
          )}

          {/* Return Deadline */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
            <div className="flex items-center gap-2 text-yellow-900 mb-2">
              <Calendar className="w-4 h-4" />
              <span className="font-medium text-sm">Return Deadline</span>
            </div>
            <p className="text-sm text-yellow-800">
              Monday, {deadlineDate.toLocaleDateString()} at 1:30 PM
            </p>
            {needsDeposit && (
              <p className="text-xs text-yellow-700 mt-1">
                • Return by deadline: 25¢ reduction<br/>
                • Each day late: Additional $1.00 reduction
              </p>
            )}
          </div>

          {/* Member Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Select Member</label>
            <select
              required
              value={selectedMemberId}
              onChange={(e) => setSelectedMemberId(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">Choose a member...</option>
              {members.filter(m => m.status === 'active').map(member => (
                <option key={member.id} value={member.id}>
                  {member.name} ({member.membershipId})
                  {member.memberPIN && ` - PIN: ${member.memberPIN}`}
                </option>
              ))}
            </select>
            {limitMessage && (
              <p className={`text-xs mt-1 ${canCheckout ? 'text-gray-600' : 'text-red-600'}`}>
                {limitMessage}
              </p>
            )}
          </div>

          {/* Payment Method - Only show if deposit required */}
          {needsDeposit && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
              <div className="space-y-2">
                <label className="flex items-center gap-3 p-3 border-2 border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                  <input
                    type="radio"
                    name="payment"
                    value="cash"
                    checked={paymentMethod === 'cash'}
                    onChange={(e) => setPaymentMethod(e.target.value as 'cash')}
                    className="w-4 h-4 text-blue-600"
                  />
                  <DollarSign className="w-5 h-5 text-green-600" />
                  <span className="flex-1 font-medium">Cash Deposit</span>
                </label>

                <label className="flex items-center gap-3 p-3 border-2 border-gray-200 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors">
                  <input
                    type="radio"
                    name="payment"
                    value="credit-card"
                    checked={paymentMethod === 'credit-card'}
                    onChange={(e) => setPaymentMethod(e.target.value as 'credit-card')}
                    className="w-4 h-4 text-blue-600"
                    disabled={!selectedMember?.creditCards?.length}
                  />
                  <CreditCard className="w-5 h-5 text-blue-600" />
                  <span className="flex-1 font-medium">
                    Credit Card
                    {!selectedMember?.creditCards?.length && (
                      <span className="text-xs text-gray-500 block">No cards on file</span>
                    )}
                  </span>
                </label>
              </div>
            </div>
          )}

          {/* Credit Card Selection */}
          {needsDeposit && paymentMethod === 'credit-card' && selectedMember?.creditCards && selectedMember.creditCards.length > 0 && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Select Card</label>
              <select
                required
                value={selectedCardId}
                onChange={(e) => setSelectedCardId(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Choose a card...</option>
                {selectedMember.creditCards.map(card => (
                  <option key={card.id} value={card.id}>
                    {card.cardType} ending in {card.lastFour}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Deposit Info */}
          {needsDeposit && paymentMethod === 'cash' && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <p className="text-sm text-green-800">
                💵 Please collect <strong>${depositAmount.toFixed(2)}</strong> cash deposit from the member.
              </p>
            </div>
          )}

          <div className="flex gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!checkoutAllowed || !canCheckout}
              className={`flex-1 px-4 py-2 rounded-lg transition-colors ${
                !checkoutAllowed || !canCheckout
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-blue-600 text-white hover:bg-blue-700'
              }`}
            >
              Process Checkout
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}