import { useState } from 'react';
import { X, Scan } from 'lucide-react';
import { Book, SHABBOS_RULES, ShabbosCategory } from '../types';
import { BarcodeScanner } from './BarcodeScanner';

interface AddBookDialogProps {
  book?: Book;
  onSave: (book: Omit<Book, 'id'>) => void;
  onClose: () => void;
}

const categories = [
  'Fiction',
  'Non-Fiction',
  'Science',
  'Technology',
  'Programming',
  'History',
  'Biography',
  'Self-Help',
  'Children',
  'Reference',
  'Other'
];

export function AddBookDialog({ book, onSave, onClose }: AddBookDialogProps) {
  const [showScanner, setShowScanner] = useState(false);
  const [formData, setFormData] = useState({
    isbn: book?.isbn || '',
    title: book?.title || '',
    author: book?.author || '',
    category: book?.category || 'Fiction',
    publishedYear: book?.publishedYear || new Date().getFullYear(),
    copies: book?.copies || 1,
    availableCopies: book?.availableCopies || 1,
    shabbosCategory: book?.shabbosCategory || 'regular' as ShabbosCategory,
    depositAmount: book?.depositAmount || 0,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...formData,
      addedDate: book?.addedDate || new Date().toISOString(),
    });
  };

  const handleScan = (code: string) => {
    setFormData(prev => ({ ...prev, isbn: code }));
    setShowScanner(false);
  };

  const selectedShabbosRule = SHABBOS_RULES[formData.shabbosCategory];

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
            <h2 className="text-xl font-semibold">
              {book ? 'Edit Book' : 'Add New Book'}
            </h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                ISBN / Barcode
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  required
                  value={formData.isbn}
                  onChange={(e) => setFormData(prev => ({ ...prev, isbn: e.target.value }))}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter or scan ISBN/Barcode"
                />
                <button
                  type="button"
                  onClick={() => setShowScanner(true)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
                >
                  <Scan className="w-4 h-4" />
                  Scan
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Title
              </label>
              <input
                type="text"
                required
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Book title"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Author
              </label>
              <input
                type="text"
                required
                value={formData.author}
                onChange={(e) => setFormData(prev => ({ ...prev, author: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Author name"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Category
                </label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData(prev => ({ ...prev, category: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Published Year
                </label>
                <input
                  type="number"
                  required
                  min="1000"
                  max={new Date().getFullYear()}
                  value={formData.publishedYear}
                  onChange={(e) => setFormData(prev => ({ ...prev, publishedYear: parseInt(e.target.value) }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* Shabbos Category */}
            <div className="border-t border-gray-200 pt-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Shabbos Lending Category
              </label>
              <select
                value={formData.shabbosCategory}
                onChange={(e) => {
                  const category = e.target.value as ShabbosCategory;
                  const rule = SHABBOS_RULES[category];
                  setFormData(prev => ({ 
                    ...prev, 
                    shabbosCategory: category,
                    depositAmount: rule.depositRange[0]
                  }));
                }}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                {Object.values(SHABBOS_RULES).map(rule => (
                  <option key={rule.category} value={rule.category}>
                    {rule.description}
                    {rule.category !== 'regular' && ` ($${rule.depositRange[0]}-$${rule.depositRange[1]} deposit)`}
                  </option>
                ))}
              </select>
              {formData.shabbosCategory !== 'regular' && (
                <div className="mt-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Deposit Amount
                  </label>
                  <input
                    type="number"
                    min={selectedShabbosRule.depositRange[0]}
                    max={selectedShabbosRule.depositRange[1]}
                    step="0.01"
                    value={formData.depositAmount}
                    onChange={(e) => setFormData(prev => ({ ...prev, depositAmount: parseFloat(e.target.value) }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Range: ${selectedShabbosRule.depositRange[0]} - ${selectedShabbosRule.depositRange[1]}
                  </p>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Total Copies
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  value={formData.copies}
                  onChange={(e) => setFormData(prev => ({ 
                    ...prev, 
                    copies: parseInt(e.target.value),
                    availableCopies: Math.min(prev.availableCopies, parseInt(e.target.value))
                  }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Available Copies
                </label>
                <input
                  type="number"
                  required
                  min="0"
                  max={formData.copies}
                  value={formData.availableCopies}
                  onChange={(e) => setFormData(prev => ({ 
                    ...prev, 
                    availableCopies: parseInt(e.target.value)
                  }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="flex gap-3 pt-4 border-t border-gray-200">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                {book ? 'Update Book' : 'Add Book'}
              </button>
            </div>
          </form>
        </div>
      </div>

      {showScanner && (
        <BarcodeScanner
          onScan={handleScan}
          onClose={() => setShowScanner(false)}
        />
      )}
    </>
  );
}