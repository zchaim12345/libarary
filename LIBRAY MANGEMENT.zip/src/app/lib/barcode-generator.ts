// Generate a barcode number for user cards
export const generateUserBarcode = (membershipId: string): string => {
  // Create a unique barcode from membership ID
  // Format: PREFIX + ID + CHECKSUM
  const prefix = '2'; // Library member cards start with 2
  const paddedId = membershipId.replace(/\D/g, '').padStart(10, '0');
  const checksum = calculateChecksum(paddedId);
  return prefix + paddedId + checksum;
};

// Calculate checksum using Luhn algorithm
const calculateChecksum = (code: string): string => {
  let sum = 0;
  let alternate = false;
  
  for (let i = code.length - 1; i >= 0; i--) {
    let digit = parseInt(code[i]);
    
    if (alternate) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    alternate = !alternate;
  }
  
  const checksum = (10 - (sum % 10)) % 10;
  return checksum.toString();
};

// Format barcode for display
export const formatBarcode = (barcode: string): string => {
  // Format as: 2 1234 5678 90 1
  if (barcode.length !== 12) return barcode;
  return `${barcode.slice(0, 1)} ${barcode.slice(1, 5)} ${barcode.slice(5, 9)} ${barcode.slice(9, 11)} ${barcode.slice(11)}`;
};

// Generate barcode image as SVG
export const generateBarcodeImage = (barcode: string): string => {
  // Simple barcode representation (Code 128 style)
  const bars: number[] = [];
  
  for (let i = 0; i < barcode.length; i++) {
    const digit = parseInt(barcode[i]);
    // Each digit creates a pattern of bars
    bars.push(digit % 2 === 0 ? 2 : 1);
    bars.push(digit % 3 === 0 ? 2 : 1);
  }
  
  let x = 0;
  const width = 2;
  const height = 60;
  let svg = `<svg width="${bars.length * width * 2}" height="${height + 20}" xmlns="http://www.w3.org/2000/svg">`;
  
  bars.forEach((bar, index) => {
    if (index % 2 === 0) {
      svg += `<rect x="${x}" y="0" width="${bar * width}" height="${height}" fill="black"/>`;
    }
    x += bar * width;
  });
  
  // Add text
  svg += `<text x="${(bars.length * width * 2) / 2}" y="${height + 15}" font-family="monospace" font-size="12" text-anchor="middle" fill="black">${formatBarcode(barcode)}</text>`;
  svg += '</svg>';
  
  return 'data:image/svg+xml;base64,' + btoa(svg);
};
