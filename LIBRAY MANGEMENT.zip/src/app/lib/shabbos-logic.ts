import { SHABBOS_RULES, ShabbosCategory, Transaction } from '../types';
import { getTransactions } from './storage';

// Calculate deposit refund based on return time
export const calculateDepositRefund = (
  depositAmount: number,
  checkoutDate: string,
  returnDate: string
): { refund: number; reduction: number; reason: string } => {
  const checkout = new Date(checkoutDate);
  const returned = new Date(returnDate);
  
  // Check if returned by Monday 1:30 PM
  const monday = getNextMonday(checkout);
  monday.setHours(13, 30, 0, 0); // 1:30 PM
  
  if (returned <= monday) {
    return {
      refund: depositAmount - 0.25,
      reduction: 0.25,
      reason: 'Returned by Monday 1:30 PM - 25¢ reduction'
    };
  }
  
  // Calculate days late
  const daysLate = Math.floor((returned.getTime() - monday.getTime()) / (1000 * 60 * 60 * 24));
  const reduction = 0.25 + (daysLate * 1.00); // 25¢ + $1 per day
  const refund = Math.max(0, depositAmount - reduction);
  
  return {
    refund,
    reduction,
    reason: `${daysLate} day(s) late - $${reduction.toFixed(2)} reduction`
  };
};

// Get next Monday from a given date
const getNextMonday = (date: Date): Date => {
  const result = new Date(date);
  const day = result.getDay();
  const daysUntilMonday = day === 0 ? 1 : day === 6 ? 2 : (8 - day) % 7;
  result.setDate(result.getDate() + daysUntilMonday);
  return result;
};

// Check if user has reached weekly limit for a category
export const checkWeeklyLimit = (
  memberId: string,
  category: ShabbosCategory
): { allowed: boolean; current: number; max: number } => {
  const transactions = getTransactions();
  const rule = SHABBOS_RULES[category];
  
  // Get start of current week (Sunday)
  const now = new Date();
  const weekStart = new Date(now);
  weekStart.setDate(now.getDate() - now.getDay());
  weekStart.setHours(0, 0, 0, 0);
  
  // Count this week's checkouts for this category
  const thisWeekCount = transactions.filter(t => {
    const checkoutDate = new Date(t.checkoutDate);
    return (
      t.memberId === memberId &&
      t.isShabbosCheckout &&
      checkoutDate >= weekStart &&
      t.status !== 'returned'
    );
  }).length;
  
  return {
    allowed: thisWeekCount < rule.maxPerWeek,
    current: thisWeekCount,
    max: rule.maxPerWeek
  };
};

// Check if today is Friday
export const isFriday = (): boolean => {
  return new Date().getDay() === 5;
};

// Check if deposit is required (only Friday)
export const isDepositRequired = (): boolean => {
  return isFriday(); // Deposit only on Friday
};

// Check if checkout is allowed (Sunday-Friday)
export const isShabbosCheckoutAllowed = (): boolean => {
  const day = new Date().getDay();
  return day >= 0 && day <= 5; // Sunday (0) through Friday (5)
};

// Get day name
export const getDayName = (date: Date = new Date()): string => {
  const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  return days[date.getDay()];
};

// Get next Friday
export const getNextFriday = (): Date => {
  const now = new Date();
  const daysUntilFriday = (5 - now.getDay() + 7) % 7;
  const friday = new Date(now);
  friday.setDate(now.getDate() + (daysUntilFriday || 7));
  friday.setHours(12, 0, 0, 0);
  return friday;
};

// Calculate return deadline (Monday 1:30 PM)
export const getReturnDeadline = (checkoutDate: string): string => {
  const checkout = new Date(checkoutDate);
  const monday = getNextMonday(checkout);
  monday.setHours(13, 30, 0, 0);
  return monday.toISOString();
};

// Format time remaining until deadline
export const formatTimeRemaining = (deadline: string): string => {
  const now = new Date();
  const end = new Date(deadline);
  const diff = end.getTime() - now.getTime();
  
  if (diff < 0) {
    const daysLate = Math.floor(Math.abs(diff) / (1000 * 60 * 60 * 24));
    return `${daysLate} day(s) overdue`;
  }
  
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  
  if (hours < 24) {
    return `${hours}h ${minutes}m remaining`;
  }
  
  const days = Math.floor(hours / 24);
  return `${days} day(s) remaining`;
};

// Validate credit card number (basic Luhn check)
export const validateCreditCard = (cardNumber: string): boolean => {
  const cleaned = cardNumber.replace(/\D/g, '');
  if (cleaned.length < 13 || cleaned.length > 19) return false;
  
  let sum = 0;
  let alternate = false;
  
  for (let i = cleaned.length - 1; i >= 0; i--) {
    let digit = parseInt(cleaned[i]);
    
    if (alternate) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    
    sum += digit;
    alternate = !alternate;
  }
  
  return sum % 10 === 0;
};

// Get card type from number
export const getCardType = (cardNumber: string): string => {
  const cleaned = cardNumber.replace(/\D/g, '');
  
  if (/^4/.test(cleaned)) return 'Visa';
  if (/^5[1-5]/.test(cleaned)) return 'Mastercard';
  if (/^3[47]/.test(cleaned)) return 'American Express';
  if (/^6(?:011|5)/.test(cleaned)) return 'Discover';
  
  return 'Unknown';
};

// Mask credit card number
export const maskCardNumber = (cardNumber: string): string => {
  const cleaned = cardNumber.replace(/\D/g, '');
  return '**** **** **** ' + cleaned.slice(-4);
};