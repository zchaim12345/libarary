import { Book, Member, Transaction } from '../types';

const BOOKS_KEY = 'library_books';
const MEMBERS_KEY = 'library_members';
const TRANSACTIONS_KEY = 'library_transactions';

// Books
export const getBooks = (): Book[] => {
  const stored = localStorage.getItem(BOOKS_KEY);
  return stored ? JSON.parse(stored) : [];
};

export const saveBooks = (books: Book[]): void => {
  localStorage.setItem(BOOKS_KEY, JSON.stringify(books));
};

export const addBook = (book: Book): void => {
  const books = getBooks();
  books.push(book);
  saveBooks(books);
};

export const updateBook = (id: string, updatedBook: Book): void => {
  const books = getBooks();
  const index = books.findIndex(b => b.id === id);
  if (index !== -1) {
    books[index] = updatedBook;
    saveBooks(books);
  }
};

export const deleteBook = (id: string): void => {
  const books = getBooks().filter(b => b.id !== id);
  saveBooks(books);
};

// Members
export const getMembers = (): Member[] => {
  const stored = localStorage.getItem(MEMBERS_KEY);
  return stored ? JSON.parse(stored) : [];
};

export const saveMembers = (members: Member[]): void => {
  localStorage.setItem(MEMBERS_KEY, JSON.stringify(members));
};

export const addMember = (member: Member): void => {
  const members = getMembers();
  members.push(member);
  saveMembers(members);
};

export const updateMember = (id: string, updatedMember: Member): void => {
  const members = getMembers();
  const index = members.findIndex(m => m.id === id);
  if (index !== -1) {
    members[index] = updatedMember;
    saveMembers(members);
  }
};

export const deleteMember = (id: string): void => {
  const members = getMembers().filter(m => m.id !== id);
  saveMembers(members);
};

// Transactions
export const getTransactions = (): Transaction[] => {
  const stored = localStorage.getItem(TRANSACTIONS_KEY);
  return stored ? JSON.parse(stored) : [];
};

export const saveTransactions = (transactions: Transaction[]): void => {
  localStorage.setItem(TRANSACTIONS_KEY, JSON.stringify(transactions));
};

export const addTransaction = (transaction: Transaction): void => {
  const transactions = getTransactions();
  transactions.push(transaction);
  saveTransactions(transactions);
};

export const updateTransaction = (id: string, updatedTransaction: Transaction): void => {
  const transactions = getTransactions();
  const index = transactions.findIndex(t => t.id === id);
  if (index !== -1) {
    transactions[index] = updatedTransaction;
    saveTransactions(transactions);
  }
};

// Initialize with sample data if empty
export const initializeSampleData = (): void => {
  if (getBooks().length === 0) {
    const sampleBooks: Book[] = [
      {
        id: '1',
        isbn: '9780132350884',
        title: 'Clean Code',
        author: 'Robert C. Martin',
        category: 'Programming',
        publishedYear: 2008,
        copies: 3,
        availableCopies: 2,
        addedDate: new Date().toISOString(),
        shabbosCategory: 'regular',
      },
      {
        id: '2',
        isbn: '9780201633610',
        title: 'Design Patterns',
        author: 'Gang of Four',
        category: 'Programming',
        publishedYear: 1994,
        copies: 2,
        availableCopies: 2,
        addedDate: new Date().toISOString(),
        shabbosCategory: 'regular',
      },
      {
        id: '3',
        isbn: '9780062316097',
        title: 'Sapiens',
        author: 'Yuval Noah Harari',
        category: 'History',
        publishedYear: 2011,
        copies: 4,
        availableCopies: 3,
        addedDate: new Date().toISOString(),
        shabbosCategory: 'regular',
      },
      {
        id: '4',
        isbn: '9781234567890',
        title: 'Superman: The Last Son',
        author: 'DC Comics',
        category: 'Children',
        publishedYear: 2020,
        copies: 5,
        availableCopies: 5,
        addedDate: new Date().toISOString(),
        shabbosCategory: 'comic-book',
        depositAmount: 5,
      },
      {
        id: '5',
        isbn: '9781234567891',
        title: 'The Chazon Ish',
        author: 'Rabbi Binyamin Rabinowitz',
        category: 'Biography',
        publishedYear: 2015,
        copies: 3,
        availableCopies: 3,
        addedDate: new Date().toISOString(),
        shabbosCategory: 'gedolim',
        depositAmount: 3,
      },
      {
        id: '6',
        isbn: '9781234567892',
        title: 'The Garden of Emuna',
        author: 'Rabbi Shalom Arush',
        category: 'Self-Help',
        publishedYear: 2011,
        copies: 4,
        availableCopies: 4,
        addedDate: new Date().toISOString(),
        shabbosCategory: 'inspirational',
        depositAmount: 3,
      },
      {
        id: '7',
        isbn: '9781234567893',
        title: 'Talmud Bavli - Berachos',
        author: 'ArtScroll',
        category: 'Reference',
        publishedYear: 2018,
        copies: 2,
        availableCopies: 2,
        addedDate: new Date().toISOString(),
        shabbosCategory: 'torah',
        depositAmount: 6,
      },
      {
        id: '8',
        isbn: '9781234567894',
        title: 'The Holocaust: A History',
        author: 'Rabbi Berel Wein',
        category: 'History',
        publishedYear: 2014,
        copies: 3,
        availableCopies: 3,
        addedDate: new Date().toISOString(),
        shabbosCategory: 'jewish-history',
        depositAmount: 2,
      },
    ];
    saveBooks(sampleBooks);
  }

  if (getMembers().length === 0) {
    const sampleMembers: Member[] = [
      {
        id: '1',
        name: 'John Doe',
        email: 'john.doe@email.com',
        phone: '555-0101',
        membershipId: 'MEM001',
        joinDate: new Date().toISOString(),
        status: 'active',
      },
      {
        id: '2',
        name: 'Jane Smith',
        email: 'jane.smith@email.com',
        phone: '555-0102',
        membershipId: 'MEM002',
        joinDate: new Date().toISOString(),
        status: 'active',
      },
    ];
    saveMembers(sampleMembers);
  }

  if (getTransactions().length === 0) {
    const sampleTransactions: Transaction[] = [
      {
        id: '1',
        bookId: '1',
        memberId: '1',
        checkoutDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
        dueDate: new Date(Date.now() + 9 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'borrowed',
      },
      {
        id: '2',
        bookId: '3',
        memberId: '2',
        checkoutDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
        dueDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(),
        status: 'borrowed',
      },
    ];
    saveTransactions(sampleTransactions);
  }
};