// Generate a random 4-digit PIN for members
export const generateMemberPIN = (): string => {
  return Math.floor(1000 + Math.random() * 9000).toString();
};

// Validate PIN format
export const validatePIN = (pin: string): boolean => {
  return /^\d{4}$/.test(pin);
};

// Generate unique PIN (check against existing PINs)
export const generateUniquePIN = (existingPINs: string[]): string => {
  let pin = generateMemberPIN();
  let attempts = 0;
  
  // Try up to 100 times to generate unique PIN
  while (existingPINs.includes(pin) && attempts < 100) {
    pin = generateMemberPIN();
    attempts++;
  }
  
  return pin;
};
