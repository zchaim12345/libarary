import { getBooks, getMembers, getTransactions, saveBooks, saveMembers, saveTransactions } from './storage';

export interface LibraryData {
  books: any[];
  members: any[];
  transactions: any[];
  exportDate: string;
  version: string;
}

export const exportData = (): string => {
  const data: LibraryData = {
    books: getBooks(),
    members: getMembers(),
    transactions: getTransactions(),
    exportDate: new Date().toISOString(),
    version: '1.0.0',
  };
  return JSON.stringify(data, null, 2);
};

export const downloadData = (): void => {
  const data = exportData();
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `library-backup-${new Date().toISOString().split('T')[0]}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

export const importData = (jsonString: string): { success: boolean; message: string } => {
  try {
    const data: LibraryData = JSON.parse(jsonString);
    
    if (!data.books || !data.members || !data.transactions) {
      return { success: false, message: 'Invalid data format' };
    }

    // Validate data structure
    if (!Array.isArray(data.books) || !Array.isArray(data.members) || !Array.isArray(data.transactions)) {
      return { success: false, message: 'Data arrays are invalid' };
    }

    saveBooks(data.books);
    saveMembers(data.members);
    saveTransactions(data.transactions);

    return { success: true, message: 'Data imported successfully' };
  } catch (error) {
    return { success: false, message: 'Failed to parse JSON file' };
  }
};

export const clearAllData = (): void => {
  if (confirm('Are you sure you want to clear all data? This action cannot be undone!')) {
    localStorage.clear();
    window.location.reload();
  }
};

// Generate CSV reports
export const exportBooksToCSV = (): void => {
  const books = getBooks();
  const headers = ['ID', 'ISBN', 'Title', 'Author', 'Category', 'Published Year', 'Total Copies', 'Available Copies'];
  const rows = books.map(book => [
    book.id,
    book.isbn,
    book.title,
    book.author,
    book.category,
    book.publishedYear,
    book.copies,
    book.availableCopies
  ]);

  const csv = [headers, ...rows].map(row => row.join(',')).join('\n');
  downloadCSV(csv, 'books-report.csv');
};

export const exportMembersToCSV = (): void => {
  const members = getMembers();
  const headers = ['ID', 'Name', 'Email', 'Phone', 'Membership ID', 'Status', 'Join Date'];
  const rows = members.map(member => [
    member.id,
    member.name,
    member.email,
    member.phone,
    member.membershipId,
    member.status,
    new Date(member.joinDate).toLocaleDateString()
  ]);

  const csv = [headers, ...rows].map(row => row.join(',')).join('\n');
  downloadCSV(csv, 'members-report.csv');
};

export const exportTransactionsToCSV = (): void => {
  const transactions = getTransactions();
  const books = getBooks();
  const members = getMembers();
  
  const headers = ['ID', 'Book Title', 'Member Name', 'Checkout Date', 'Due Date', 'Return Date', 'Status', 'Fine'];
  const rows = transactions.map(transaction => {
    const book = books.find(b => b.id === transaction.bookId);
    const member = members.find(m => m.id === transaction.memberId);
    return [
      transaction.id,
      book?.title || 'Unknown',
      member?.name || 'Unknown',
      new Date(transaction.checkoutDate).toLocaleDateString(),
      new Date(transaction.dueDate).toLocaleDateString(),
      transaction.returnDate ? new Date(transaction.returnDate).toLocaleDateString() : 'Not returned',
      transaction.status,
      transaction.fine || 0
    ];
  });

  const csv = [headers, ...rows].map(row => row.join(',')).join('\n');
  downloadCSV(csv, 'transactions-report.csv');
};

const downloadCSV = (csv: string, filename: string): void => {
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};
