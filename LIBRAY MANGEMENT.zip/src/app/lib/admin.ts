import { AdminSettings, ActivityLog } from '../types';

const ADMIN_SETTINGS_KEY = 'library_admin_settings';
const ACTIVITY_LOG_KEY = 'library_activity_log';
const ADMIN_SESSION_KEY = 'library_admin_session';

const DEFAULT_ADMIN_CODE = '1234'; // Default admin code

export const getAdminSettings = (): AdminSettings => {
  const stored = localStorage.getItem(ADMIN_SETTINGS_KEY);
  if (stored) {
    return JSON.parse(stored);
  }
  
  // Default settings
  const defaultSettings: AdminSettings = {
    adminCode: DEFAULT_ADMIN_CODE,
    libraryName: 'Zichron Chaim Library',
    allowGuestCheckout: false,
    defaultLoanPeriod: 14,
    lateFeePerDay: 0.50,
    maxBooksPerMember: 5,
  };
  
  saveAdminSettings(defaultSettings);
  return defaultSettings;
};

export const saveAdminSettings = (settings: AdminSettings): void => {
  localStorage.setItem(ADMIN_SETTINGS_KEY, JSON.stringify(settings));
};

export const verifyAdminCode = (code: string): boolean => {
  const settings = getAdminSettings();
  return code === settings.adminCode;
};

export const updateAdminCode = (oldCode: string, newCode: string): boolean => {
  if (!verifyAdminCode(oldCode)) {
    return false;
  }
  
  const settings = getAdminSettings();
  settings.adminCode = newCode;
  saveAdminSettings(settings);
  return true;
};

// Admin Session Management
export const setAdminSession = (isAdmin: boolean): void => {
  const session = {
    isAdmin,
    timestamp: Date.now(),
    expiresAt: Date.now() + (4 * 60 * 60 * 1000) // 4 hours
  };
  localStorage.setItem(ADMIN_SESSION_KEY, JSON.stringify(session));
};

export const checkAdminSession = (): boolean => {
  const stored = localStorage.getItem(ADMIN_SESSION_KEY);
  if (!stored) return false;
  
  const session = JSON.parse(stored);
  if (Date.now() > session.expiresAt) {
    clearAdminSession();
    return false;
  }
  
  return session.isAdmin;
};

export const clearAdminSession = (): void => {
  localStorage.removeItem(ADMIN_SESSION_KEY);
};

// Activity Logging
export const getActivityLog = (): ActivityLog[] => {
  const stored = localStorage.getItem(ACTIVITY_LOG_KEY);
  return stored ? JSON.parse(stored) : [];
};

export const addActivityLog = (log: Omit<ActivityLog, 'id' | 'timestamp'>): void => {
  const logs = getActivityLog();
  const newLog: ActivityLog = {
    ...log,
    id: Date.now().toString(),
    timestamp: new Date().toISOString(),
  };
  
  logs.unshift(newLog); // Add to beginning
  
  // Keep only last 500 logs
  if (logs.length > 500) {
    logs.splice(500);
  }
  
  localStorage.setItem(ACTIVITY_LOG_KEY, JSON.stringify(logs));
};

export const clearActivityLog = (): void => {
  localStorage.removeItem(ACTIVITY_LOG_KEY);
};