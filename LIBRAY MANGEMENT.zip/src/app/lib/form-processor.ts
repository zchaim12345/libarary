// Form data extraction from images (simulated OCR)
// In production, this would use Tesseract.js or similar

export interface BorrowingFormData {
  memberName: string;
  membershipId: string;
  bookTitle: string;
  bookISBN: string;
  borrowDate: string;
  dueDate: string;
  librarian: string;
}

export interface ReturnFormData {
  memberName: string;
  membershipId: string;
  bookTitle: string;
  returnDate: string;
  condition: 'excellent' | 'good' | 'fair' | 'damaged';
  notes: string;
  librarian: string;
}

export interface ShabbosFormData {
  memberName: string;
  membershipId: string;
  bookTitle: string;
  category: string;
  depositAmount: number;
  paymentMethod: 'cash' | 'credit-card';
  checkoutDate: string;
  librarian: string;
}

// Simulate form data extraction from image
export const extractBorrowingFormData = async (imageData: string): Promise<BorrowingFormData> => {
  // In production, use OCR library like Tesseract.js
  // For now, return template for manual entry
  return {
    memberName: '',
    membershipId: '',
    bookTitle: '',
    bookISBN: '',
    borrowDate: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    librarian: 'Admin',
  };
};

export const extractReturnFormData = async (imageData: string): Promise<ReturnFormData> => {
  return {
    memberName: '',
    membershipId: '',
    bookTitle: '',
    returnDate: new Date().toISOString().split('T')[0],
    condition: 'good',
    notes: '',
    librarian: 'Admin',
  };
};

export const extractShabbosFormData = async (imageData: string): Promise<ShabbosFormData> => {
  return {
    memberName: '',
    membershipId: '',
    bookTitle: '',
    category: '',
    depositAmount: 0,
    paymentMethod: 'cash',
    checkoutDate: new Date().toISOString().split('T')[0],
    librarian: 'Admin',
  };
};

// Generate PDF form templates
export const generateBorrowingFormPDF = (): string => {
  return `
LIBRARY BORROWING FORM
=====================================================

Date: ________________        Time: ________________

MEMBER INFORMATION:
Name: _____________________________________________
Membership ID: ____________________________________
Phone: ____________________________________________

BOOK INFORMATION:
Title: _____________________________________________
Author: ___________________________________________
ISBN/Barcode: _____________________________________
Category: _________________________________________

CHECKOUT DETAILS:
Checkout Date: ____________________________________
Due Date: _________________________________________
(Standard: 14 days from checkout)

CONDITION CHECK:
☐ Excellent  ☐ Good  ☐ Fair  ☐ Damaged

Special Instructions:
_____________________________________________________
_____________________________________________________

SIGNATURES:
Librarian: ________________  Date: ________________
Member: ___________________  Date: ________________

TERMS & CONDITIONS:
• Books must be returned by the due date
• Late fee: $0.50 per day
• Lost/damaged books: Full replacement cost
• Maximum 5 books per member

Office Use Only:
Transaction ID: ___________________________________
Processed by: _____________________________________
  `;
};

export const generateReturnFormPDF = (): string => {
  return `
LIBRARY RETURN FORM
=====================================================

Date: ________________        Time: ________________

MEMBER INFORMATION:
Name: _____________________________________________
Membership ID: ____________________________________

BOOK INFORMATION:
Title: _____________________________________________
ISBN/Barcode: _____________________________________

RETURN DETAILS:
Return Date: ______________________________________
Due Date: _________________________________________
Days Late: ________________________________________

CONDITION ASSESSMENT:
☐ Excellent - Like new
☐ Good - Normal wear
☐ Fair - Noticeable wear
☐ Damaged - Needs repair/replacement

DAMAGE DESCRIPTION (if applicable):
_____________________________________________________
_____________________________________________________
_____________________________________________________

LATE FEES:
Days Overdue: _____________________________________
Fee per Day: $0.50
Total Late Fee: $ _________________________________

PAYMENT:
☐ Cash    ☐ Credit Card    ☐ Waived
Amount Paid: $ ____________________________________

NOTES:
_____________________________________________________
_____________________________________________________

SIGNATURES:
Librarian: ________________  Date: ________________
Member: ___________________  Date: ________________

Office Use Only:
Transaction ID: ___________________________________
Processed by: _____________________________________
  `;
};

export const generateShabbosFormPDF = (): string => {
  return `
SHABBOS LEARNING PROGRAM - CHECKOUT FORM
=====================================================

Date: ________________        Day: ________________

MEMBER INFORMATION:
Name: _____________________________________________
Membership ID: ____________________________________
Phone: ____________________________________________

BOOK INFORMATION:
Title: _____________________________________________
Author: ___________________________________________
Barcode: __________________________________________

BOOK CATEGORY (Check One):
☐ Comic Books ($5 deposit, max 1/week)
☐ Gedolim Biographies ($3 deposit, max 2/week)
☐ Inspirational Stories ($1-3 deposit, max 1/week)
☐ Torah & Texts ($4-6 deposit, unlimited)
☐ Jewish History ($1-3 deposit, max 1/week)

DEPOSIT AMOUNT: $ _________________________________

PAYMENT METHOD:
☐ Cash Deposit
☐ Credit Card (last 4 digits): ____________________

CHECKOUT DETAILS:
Checkout Day: _____________________________________
(Sunday-Friday only)

Return Deadline: MONDAY 1:30 PM
Late Return Policy:
• Return by Monday 1:30 PM: 25¢ reduction
• Each day late: $1.00 reduction

DEPOSIT REFUND CALCULATION:
Deposit Amount: $ _________________________________
Less Reduction: $ _________________________________
Refund Amount: $ __________________________________

MEMBER AGREEMENT:
I understand that:
• Shabbos checkouts are Sunday-Friday only
• Friday checkouts require deposit
• All books due Monday 1:30 PM
• Late returns incur deposit reductions
• I am responsible for book condition

Member Signature: ________________  Date: _________

LIBRARIAN USE ONLY:
Librarian Name: ___________________________________
Weekly Limit Check: ☐ Approved  ☐ Limit Reached
Deposit Collected: ☐ Yes  ☐ No
Transaction ID: ___________________________________

RETURN SECTION (Complete on return):
Return Date: ______________________________________
Return Time: ______________________________________
Book Condition: ☐ Good  ☐ Damaged
Refund Issued: $ __________________________________
Refund Method: ☐ Cash  ☐ Credit Card
Librarian: ________________  Date: ________________
  `;
};

export const generateMemberApplicationPDF = (): string => {
  return `
LIBRARY MEMBERSHIP APPLICATION
=====================================================

APPLICATION DATE: _________________________________

PERSONAL INFORMATION:
Full Name: ________________________________________
Date of Birth: ____________________________________
Phone Number: _____________________________________
Email Address: ____________________________________

ADDRESS:
Street: ___________________________________________
City: _____________________________________________
State: ____________  ZIP: _________________________

EMERGENCY CONTACT:
Name: _____________________________________________
Relationship: _____________________________________
Phone: ____________________________________________

IDENTIFICATION:
☐ Driver's License
☐ State ID
☐ Passport
☐ Other: _________________________________________
ID Number: ________________________________________

MEMBERSHIP TYPE:
☐ Individual ($0 - Free)
☐ Family ($0 - Free)
☐ Student ($0 - Free)

TERMS & CONDITIONS:
I agree to:
• Return all borrowed materials on time
• Pay all fines and fees promptly
• Maintain materials in good condition
• Notify library of address/contact changes
• Follow all library rules and policies

Applicant Signature: _____________  Date: _________

Parent/Guardian (if under 18):
Name: _____________________________________________
Signature: ________________  Date: ________________

OFFICE USE ONLY:
Membership ID: ____________________________________
Barcode Generated: ________________________________
PIN Assigned: _____________________________________
Card Issued: ☐ Yes  Date: ________________________
Processed By: _____________________________________
Approved By: ______________________________________

NOTES:
_____________________________________________________
_____________________________________________________
  `;
};

export const generateBookAdditionPDF = (): string => {
  return `
LIBRARY BOOK ADDITION FORM
=====================================================

DATE ADDED: _______________________________________

BOOK INFORMATION:
Title: ____________________________________________
Author: ___________________________________________
ISBN: _____________________________________________
Publisher: ________________________________________
Publication Year: _________________________________

CLASSIFICATION:
Category: _________________________________________
☐ Fiction  ☐ Non-Fiction  ☐ Reference  ☐ Children

Shabbos Category:
☐ Regular (No deposit)
☐ Comic Books ($5 deposit)
☐ Gedolim ($3 deposit)
☐ Inspirational ($1-3 deposit)
☐ Torah/Texts ($4-6 deposit)
☐ Jewish History ($1-3 deposit)

Deposit Amount: $ _________________________________

INVENTORY:
Number of Copies: _________________________________
Barcode Numbers:
1. _______________________________________________
2. _______________________________________________
3. _______________________________________________
4. _______________________________________________
5. _______________________________________________

CONDITION:
☐ New  ☐ Like New  ☐ Good  ☐ Fair

ACQUISITION:
☐ Purchase - Cost: $ ______________________________
☐ Donation - Donor: _______________________________
☐ Gift
☐ Other: _________________________________________

LOCATION:
Shelf/Section: ____________________________________
Call Number: ______________________________________

CATALOGING:
Date Cataloged: ___________________________________
Cataloged By: _____________________________________

APPROVAL:
Library Director: _____________  Date: ___________

NOTES:
_____________________________________________________
_____________________________________________________
_____________________________________________________
  `;
};
