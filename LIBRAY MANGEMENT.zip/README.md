# Zichron Chaim Library - Offline Library Management System

A comprehensive, **fully offline** library management system with barcode scanning, form processing, donations, and admin controls.

## 🎯 Key Features

### **📚 Complete Library System:**
- Barcode scanning (books & member cards)
- Member PINs (4-digit quick ID)
- Form processing (upload filled forms)
- Downloadable PDF forms
- Book & member management
- Transaction tracking
- Shabbos lending program
- Donation management

### **💝 Donation System:**
- **Prominent donate button** in sidebar
- Multiple payment methods (Cash, Card, Check)
- Chai multiples ($18, $36, $54, etc.)
- Anonymous donation option
- Donor wall of honor ($180+)
- Tax-deductible tracking
- Message/dedication support
- Admin-only donation viewing

### **💳 Credit Card for Shabbos:**
- Add CC info in User Profiles
- Multiple cards per member
- Set default payment method
- Auto-fill at Shabbos checkout
- Friday deposits via stored CC
- Sunday-Thursday NO deposit (FREE)

### **🔌 100% Offline:**
- No internet required
- All data local storage
- Service worker caching
- PWA installable
- Runs from USB
- See `OFFLINE-READY.md`

## 🚀 Quick Build (Create EXE)

**Windows - One Command:**
```bash
npm run build:exe:windows
```

**Or step-by-step:**
```bash
npm install
npm run build
BUILD-EXE.bat
```

**Output:** `Release/LibraryOS/LibraryOS.exe`

📖 **Full Instructions:** See `DOWNLOAD-AND-BUILD.md`

## 🎯 Features

### **Core System:**
- 📱 **Barcode Scanner** - Scan books & member cards using device camera
- 🔢 **Member PINs** - 4-digit quick identification
- 📋 **Form Processing** - Upload filled paper forms (OCR ready)
- 🖨️ **PDF Forms** - Download blank forms for borrowing, returns, Shabbos lending
- 📚 **Book Management** - Complete CRUD with Shabbos categories
- 👥 **Member Management** - With auto-generated cards & barcodes
- 🔄 **Transactions** - Check-in/out with due date tracking
- 📊 **Reports & Analytics** - Visual charts and statistics

### **Shabbos Lending:**
- **Sunday-Thursday**: FREE checkouts (no deposit)
- **Friday**: Deposit required ($1-6 based on category)
- **Saturday**: No checkouts
- **Return Deadline**: Monday 1:30 PM
- **Late Fees**: 25¢ on-time, $1/day late

### **Admin Features:**
- 🔐 **Secure Access** - Password protected (default: 1234)
- 🚫 **Ban System** - Ban members with full-screen alerts
- 📝 **Activity Logging** - Track all admin actions
- ⚙️ **System Settings** - Configure fees, periods, limits
- 📥 **Form Upload** - Process paper forms via image upload
- 🔒 **Access Control** - Only admins can add books/members

### **Forms Available:**
1. **Borrowing Form** - Standard checkout
2. **Return Form** - Book returns with condition check
3. **Shabbos Learning Form** - Special Shabbos program
4. **Member Application** - New member registration
5. **Book Addition Form** - Add new books to catalog

## 📋 Form Workflow

1. **Download** blank form from system
2. **Print** and fill out by hand
3. **Scan/Photo** the completed form
4. **Upload** to system
5. **Extract** data automatically (OCR)
6. **Review** and save

## 🛡️ Admin-Only Features

- Add/Edit/Delete Books
- Add/Edit/Delete Members  
- Ban/Unban Users
- Change Admin Code
- View Activity Logs
- System Settings
- Form Processing

**Regular users can:**
- Check out books
- Return books
- View their profile
- Scan barcodes

## 💾 Data Management

### Backup
1. Go to Settings → Export All Data
2. Save JSON file

### Restore
1. Go to Settings → Import Data
2. Select backup file

### Export Reports (CSV)
- Books inventory
- Members list
- Transaction history

## 🎨 Customization

### Change Admin Code
1. Login to Admin Panel
2. Go to "Admin Code" section
3. Enter current + new code

### Change Library Name
1. Admin Panel → System Settings
2. Update "Library Name"

### Adjust Fees & Periods
- Default loan period
- Late fee per day
- Max books per member

## 📱 User Cards

Each member gets:
- **Barcode** - Auto-generated for scanning
- **4-Digit PIN** - Quick checkout
- **Printable Card** - With both barcode & PIN

## 📊 Dashboard Features

- **Due Soon** - Books due in next 4 days
- **Shabbos Books** - Highlighted with Monday deadline
- **Statistics** - Real-time library stats
- **Recent Activity** - Last 5 transactions
- **Quick Actions** - One-click access

## 🔧 System Requirements

**For Building:**
- Node.js 16+ (https://nodejs.org)
- Python 3.8+ (optional, for best EXE)

**For Running (End Users):**
- Windows 7 or later
- **NO Node.js required!**
- Webcam for barcode scanning (optional)

## 🚀 Quick Start

### Development
```bash
npm install
npm run dev
```

### Production Build
```bash
npm run build
```

### Create EXE
```bash
npm run build:exe:windows
```

## 📦 Distribution

1. Build EXE: `npm run build:exe:windows`
2. Find in: `Release/LibraryOS/`
3. Zip the folder
4. Share with users
5. They extract and run `LibraryOS.exe`

## 🔐 Security

- Admin code required for sensitive operations
- Session timeout (4 hours)
- Activity logging
- Ban system with alerts
- Local data storage (no cloud)

## 🆘 Troubleshooting

**Build fails?**
- Run `BUILD-EXE.bat` and choose HTA method
- Or use Portable Chrome method

**Camera not working?**
- Grant camera permissions
- Use Portable Chrome build method

**Data lost?**
- Restore from Settings → Import Data
- Regular backups recommended

## 📚 Documentation

- `DOWNLOAD-AND-BUILD.md` - Complete build guide
- `STANDALONE-EXE-GUIDE.md` - All EXE methods
- `QUICK-START.txt` - Quick reference
- `BUILD-EXE.bat` - Interactive builder

## 🎯 Use Cases

- School libraries
- Shul/Synagogue lending libraries
- Community book exchanges
- Private collections
- Small library management

## ⚡ Advanced Features

- Member card printing
- Credit card storage (local)
- Weekly checkout limits
- Deposit tracking
- Fine calculations
- Overdue notifications
- Bulk operations
- CSV exports

## 🔒 Updates

To update deployed app:
1. Make changes
2. Rebuild: `npm run build:exe:windows`  
3. Replace old EXE
4. User data preserved

## 📞 Support

For issues:
1. Check documentation files
2. Review error messages
3. Try alternative build methods
4. Check system requirements

## 📄 License

Proprietary - For internal use only

## 🎉 Ready?

```bash
npm run build:exe:windows
```

**Your complete library management system awaits!** 📚