@echo off
echo Creating Portable Chrome Launcher...

(
echo @echo off
echo title LibraryOS - Library Management System
echo cd /d "%%~dp0"
echo.
echo REM Check if Chrome Portable exists
echo if not exist "ChromePortable\GoogleChromePortable.exe" ^(
echo     echo ERROR: Chrome Portable not found!
echo     echo.
echo     echo Please download Chrome Portable from:
echo     echo https://portableapps.com/apps/internet/google_chrome_portable
echo     echo.
echo     echo Extract it to a folder named "ChromePortable" in this directory.
echo     echo.
echo     pause
echo     exit
echo ^)
echo.
echo REM Check if dist folder exists
echo if not exist "dist\index.html" ^(
echo     echo ERROR: App not built!
echo     echo.
echo     echo Please run: npm run build
echo     echo.
echo     pause
echo     exit
echo ^)
echo.
echo REM Launch LibraryOS
echo echo Starting LibraryOS...
echo start "" "ChromePortable\GoogleChromePortable.exe" --app="file:///%%~dp0dist/index.html" --window-size=1400,900 --disable-web-security --user-data-dir="%%~dp0userdata"
echo.
echo REM Wait a moment then close this window
echo timeout /t 2 /nobreak ^>nul
echo exit
) > LibraryOS-Portable.bat

echo.
echo ✓ LibraryOS-Portable.bat created successfully!
echo.
echo Setup Instructions:
echo 1. Run: npm run build
echo 2. Download Chrome Portable from: https://portableapps.com/apps/internet/google_chrome_portable
echo 3. Extract to "ChromePortable" folder here
echo 4. Double-click LibraryOS-Portable.bat
echo.
pause
