#!/usr/bin/env node
/**
 * Automatic EXE Builder for LibraryOS
 * Run: node auto-build.js
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('\n========================================');
console.log('  LibraryOS - Automatic EXE Builder');
console.log('========================================\n');

const steps = [
  {
    name: 'Installing dependencies',
    command: 'npm install',
  },
  {
    name: 'Building web application',
    command: 'npm run build',
  },
  {
    name: 'Installing Python packages',
    command: 'pip install pywebview pyinstaller pyinstaller-hooks-contrib',
    skipOnError: true,
  },
  {
    name: 'Building standalone EXE',
    command: 'pyinstaller --noconfirm --onefile --windowed --name "LibraryOS" --add-data "dist;dist" launcher.py',
    skipOnError: true,
  },
];

function executeStep(step, index) {
  console.log(`[${index + 1}/${steps.length}] ${step.name}...`);
  
  try {
    execSync(step.command, { stdio: 'inherit' });
    console.log('✓ Success\n');
    return true;
  } catch (error) {
    console.error('✗ Failed\n');
    if (!step.skipOnError) {
      throw error;
    }
    return false;
  }
}

async function build() {
  try {
    // Execute all steps
    for (let i = 0; i < steps.length; i++) {
      executeStep(steps[i], i);
    }

    // Organize output
    console.log('Organizing files...');
    const releaseDir = path.join(__dirname, 'Release', 'LibraryOS');
    
    if (!fs.existsSync(releaseDir)) {
      fs.mkdirSync(releaseDir, { recursive: true });
    }

    console.log('\n========================================');
    console.log('  BUILD COMPLETE!');
    console.log('========================================\n');
    console.log('Your standalone application is ready!\n');
    console.log('Location: Release/LibraryOS/\n');
    console.log('To distribute:');
    console.log('  1. Zip the entire "LibraryOS" folder');
    console.log('  2. Share the zip file');
    console.log('  3. Users extract and run LibraryOS.exe\n');

  } catch (error) {
    console.error('\n❌ Build failed!');
    console.error('Error:', error.message);
    console.log('\nTroubleshooting:');
    console.log('  1. Ensure Python is installed');
    console.log('  2. Ensure pip is available');
    console.log('  3. Run: npm install');
    console.log('  4. Try BUILD-EXE.bat for alternative methods\n');
    process.exit(1);
  }
}

build();
