# Create Standalone EXE (NO NODE.JS REQUIRED)

This guide shows how to create a **standalone .exe file** that runs on any Windows PC **without installing Node.js**.

---

## ⚡ QUICK & EASY METHODS

### Method 1: WebView2 Desktop App (RECOMMENDED - Tiny ~2 MB!)

This creates a true Windows native app using Microsoft Edge WebView2.

#### What You Need:
- Python 3.x (just for the build tool)
- Windows 10/11

#### Steps:

1. **First, build your web app:**
```bash
npm run build
```
This creates the `dist/` folder with your app.

2. **Download pywebview:**
```bash
pip install pywebview
```

3. **Create `launcher.py` in project root:**
```python
import webview
import os
import sys

def get_app_path():
    if getattr(sys, 'frozen', False):
        # Running as compiled exe
        return os.path.dirname(sys.executable)
    else:
        # Running as script
        return os.path.dirname(os.path.abspath(__file__))

def main():
    app_path = get_app_path()
    html_path = os.path.join(app_path, 'dist', 'index.html')
    
    window = webview.create_window(
        'LibraryOS - Library Management System',
        'file:///' + html_path.replace('\\', '/'),
        width=1400,
        height=900,
        min_size=(800, 600),
        resizable=True,
        fullscreen=False,
        background_color='#FFFFFF'
    )
    
    webview.start(debug=False)

if __name__ == '__main__':
    main()
```

4. **Install PyInstaller:**
```bash
pip install pyinstaller
```

5. **Create the EXE:**
```bash
pyinstaller --onefile --windowed --name LibraryOS --icon=icon.ico launcher.py
```

6. **Copy your dist folder:**
```bash
# Copy the built web app to the same folder as the exe
xcopy /E /I dist\ dist_exe\LibraryOS\dist
copy dist_exe\LibraryOS.exe dist_exe\LibraryOS\
```

7. **Done! Your app is in `dist_exe/LibraryOS/`**
   - `LibraryOS.exe` - Your standalone executable
   - `dist/` folder - Your web app files

**To distribute:** Zip the entire `LibraryOS` folder and share it!

---

### Method 2: HTML Application (HTA) - EASIEST! No Build Tools!

This works on ALL Windows versions, no installation needed!

#### Steps:

1. **Build your app:**
```bash
npm run build
```

2. **Create `LibraryOS.hta` in the project root:**
```html
<!DOCTYPE html>
<html>
<head>
    <HTA:APPLICATION 
        ID="LibraryOS"
        APPLICATIONNAME="LibraryOS"
        BORDER="thick"
        BORDERSTYLE="normal"
        CAPTION="yes"
        ICON="icon.ico"
        MAXIMIZEBUTTON="yes"
        MINIMIZEBUTTON="yes"
        SHOWINTASKBAR="yes"
        SINGLEINSTANCE="yes"
        SYSMENU="yes"
        VERSION="1.0"
        WINDOWSTATE="maximize"
    />
    <title>LibraryOS</title>
    <script>
        window.location = 'dist/index.html';
    </script>
</head>
<body>
    <p>Loading LibraryOS...</p>
</body>
</html>
```

3. **Done! Just double-click `LibraryOS.hta` to run!**

**To distribute:** 
- Zip the entire folder (including `dist/` and `LibraryOS.hta`)
- Users just extract and double-click the .hta file!

**Note:** HTA is old technology but works perfectly for offline apps.

---

### Method 3: Neutralinojs (Modern & Lightweight ~3 MB)

Creates a modern desktop app without Node.js runtime.

#### Steps:

1. **Download Neutralinojs:**
   - Go to: https://github.com/neutralinojs/neutralinojs/releases
   - Download `neutralinojs-windows_x64.zip`

2. **Extract and setup:**
```
LibraryOS/
├── dist/              (your built app)
├── neutralino-win_x64.exe
└── neutralino.config.json
```

3. **Create `neutralino.config.json`:**
```json
{
  "applicationId": "com.libraryos.app",
  "version": "1.0.0",
  "defaultMode": "window",
  "port": 0,
  "documentRoot": "/dist/",
  "url": "/index.html",
  "enableServer": true,
  "enableNativeAPI": true,
  "modes": {
    "window": {
      "title": "LibraryOS",
      "width": 1400,
      "height": 900,
      "minWidth": 800,
      "minHeight": 600,
      "fullScreen": false,
      "alwaysOnTop": false,
      "icon": "/icon.png",
      "enableInspector": false,
      "borderless": false,
      "maximize": false,
      "hidden": false,
      "resizable": true,
      "exitProcessOnClose": true
    }
  }
}
```

4. **Rename the exe:**
```bash
ren neutralino-win_x64.exe LibraryOS.exe
```

5. **Done! Run `LibraryOS.exe`**

---

### Method 4: WebView2 C# Wrapper (Professional - Pure Windows)

For a truly professional Windows app.

#### You need:
- Visual Studio Community (free)

#### Quick Setup:

1. **Create new WPF App in Visual Studio**

2. **Install WebView2 NuGet package**

3. **Add this code to MainWindow.xaml.cs:**
```csharp
using Microsoft.Web.WebView2.Core;
using System.IO;
using System.Windows;

namespace LibraryOS
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            InitializeAsync();
        }

        async void InitializeAsync()
        {
            await webView.EnsureCoreWebView2Async(null);
            
            string appPath = System.AppDomain.CurrentDomain.BaseDirectory;
            string htmlPath = Path.Combine(appPath, "dist", "index.html");
            
            webView.CoreWebView2.Navigate(new Uri(htmlPath).AbsoluteUri);
        }
    }
}
```

4. **Add to MainWindow.xaml:**
```xml
<Window x:Class="LibraryOS.MainWindow"
        xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        xmlns:wv2="clr-namespace:Microsoft.Web.WebView2.Wpf;assembly=Microsoft.Web.WebView2.Wpf"
        Title="LibraryOS" Height="900" Width="1400">
    <Grid>
        <wv2:WebView2 Name="webView" Source="about:blank"/>
    </Grid>
</Window>
```

5. **Build → Publish**
   - Creates standalone .exe with all dependencies

---

## 🎯 SIMPLEST SOLUTION - PORTABLE BROWSER

### Pre-Built Solution (No coding!)

1. **Build your app:**
```bash
npm run build
```

2. **Download Portable Browser:**
   - Chrome Portable: https://portableapps.com/apps/internet/google_chrome_portable
   - OR Edge Portable: https://portableapps.com/apps/internet/microsoft-edge-portable

3. **Create folder structure:**
```
LibraryOS/
├── dist/                    (your built app)
├── ChromePortable/          (portable chrome)
└── LibraryOS.bat           (launcher)
```

4. **Create `LibraryOS.bat`:**
```batch
@echo off
title LibraryOS
cd /d "%~dp0"
start "" "ChromePortable\GoogleChromePortable.exe" --app="file:///%~dp0dist/index.html" --window-size=1400,900 --disable-web-security --user-data-dir="%~dp0userdata"
exit
```

5. **Create Desktop Shortcut:**
   - Right-click `LibraryOS.bat` → Send to → Desktop (create shortcut)
   - Right-click shortcut → Properties → Change Icon

6. **Done!** Distribute the entire folder.

---

## 📊 COMPARISON

| Method | Size | Difficulty | Professional Look | Camera Support |
|--------|------|------------|-------------------|----------------|
| **HTA** | 1 MB | ⭐ Easy | Basic | ⚠️ Limited |
| **PyWebView** | 2-5 MB | ⭐⭐ Medium | Good | ✅ Yes |
| **Neutralino** | 3 MB | ⭐⭐ Medium | Excellent | ✅ Yes |
| **C# WebView2** | 5-10 MB | ⭐⭐⭐ Hard | Excellent | ✅ Yes |
| **Portable Chrome** | 80 MB | ⭐ Easy | Good | ✅ Yes |

---

## 🎨 CREATING AN ICON

### Online Tools (Free):
1. Go to: https://favicon.io/favicon-converter/
2. Upload your logo image
3. Download as .ico file
4. Save as `icon.ico` in project root

### Or use default Windows icon:
```
C:\Windows\System32\shell32.dll
```
Select icon #165 (folder) or #21 (document)

---

## ✅ RECOMMENDED WORKFLOW

**For Quick Testing:**
→ Use **HTA** or **Portable Chrome**

**For Distribution:**
→ Use **PyWebView** or **Neutralino** (small, professional)

**For Professional/Commercial:**
→ Use **C# WebView2** (best Windows integration)

---

## 🚀 FINAL DISTRIBUTION

### Option A: ZIP File
```
LibraryOS_v1.0.zip
├── LibraryOS.exe
├── dist/
├── icon.ico
└── README.txt
```

### Option B: Installer (Advanced)
Use **Inno Setup** (free) to create professional installer:
1. Download: https://jrsoftware.org/isinfo.php
2. Create installer script
3. Generates `LibraryOS_Setup.exe`

---

## 💡 TIPS

1. **Camera access** works in all methods except HTA
2. **Data storage** persists in browser's localStorage
3. **No internet needed** - fully offline
4. **Test on clean Windows PC** before distributing
5. **Include README** with instructions

---

## ⚡ SUPER QUICK START

**Want it running in 2 minutes?**

1. Run: `npm run build`
2. Download: Chrome Portable
3. Create: `run.bat` file (see above)
4. Double-click `run.bat`
5. Done! ✅

Your library management system is now a standalone Windows application!
