@echo off
echo Creating HTML Application (HTA) launcher...

(
echo ^<!DOCTYPE html^>
echo ^<html^>
echo ^<head^>
echo     ^<HTA:APPLICATION 
echo         ID="LibraryOS"
echo         APPLICATIONNAME="LibraryOS - Library Management System"
echo         BORDER="thick"
echo         BORDERSTYLE="normal"
echo         CAPTION="yes"
echo         MAXIMIZEBUTTON="yes"
echo         MINIMIZEBUTTON="yes"
echo         SHOWINTASKBAR="yes"
echo         SINGLEINSTANCE="yes"
echo         SYSMENU="yes"
echo         VERSION="1.0"
echo         WINDOWSTATE="maximize"
echo     /^>
echo     ^<title^>LibraryOS^</title^>
echo     ^<script^>
echo         window.location = 'dist/index.html';
echo     ^</script^>
echo ^</head^>
echo ^<body^>
echo     ^<div style="display: flex; align-items: center; justify-content: center; height: 100vh; font-family: Arial;"^>
echo         ^<div style="text-align: center;"^>
echo             ^<h1^>Loading LibraryOS...^</h1^>
echo             ^<p^>Please wait while the application starts.^</p^>
echo         ^</div^>
echo     ^</div^>
echo ^</body^>
echo ^</html^>
) > LibraryOS.hta

echo.
echo ✓ LibraryOS.hta created successfully!
echo.
echo To use:
echo 1. First run: npm run build
echo 2. Then double-click LibraryOS.hta
echo.
pause
