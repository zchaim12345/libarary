@echo off
title LibraryOS - Build Standalone EXE
color 0A

echo.
echo ========================================
echo   LibraryOS - Build Standalone EXE
echo ========================================
echo.

:menu
echo Choose your build method:
echo.
echo 1. Build Web App (Required First!)
echo 2. Create HTA Launcher (Easiest - No dependencies)
echo 3. Create Portable Chrome Launcher
echo 4. Build Python EXE (Requires Python)
echo 5. Instructions for Other Methods
echo 6. Exit
echo.
set /p choice="Enter your choice (1-6): "

if "%choice%"=="1" goto build_web
if "%choice%"=="2" goto create_hta
if "%choice%"=="3" goto create_portable
if "%choice%"=="4" goto build_python
if "%choice%"=="5" goto show_instructions
if "%choice%"=="6" goto end

echo Invalid choice! Please try again.
echo.
goto menu

:build_web
echo.
echo Building web application...
call npm run build
if errorlevel 1 (
    echo.
    echo ERROR: Build failed!
    echo Make sure you have run 'npm install' first.
    pause
    goto menu
)
echo.
echo ✓ Web app built successfully in 'dist' folder!
echo.
pause
goto menu

:create_hta
echo.
echo Creating HTA launcher...
call create-hta.bat
echo.
echo ✓ Done! Double-click 'LibraryOS.hta' to run the app.
echo.
pause
goto menu

:create_portable
echo.
echo Creating Portable Chrome launcher...
call create-portable-launcher.bat
echo.
echo Next steps:
echo 1. Download Chrome Portable from: https://portableapps.com/apps/internet/google_chrome_portable
echo 2. Extract to 'ChromePortable' folder
echo 3. Double-click LibraryOS-Portable.bat
echo.
pause
goto menu

:build_python
echo.
echo Building Python-based standalone EXE...
echo.
echo Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed!
    echo.
    echo Please install Python from: https://www.python.org/downloads/
    echo Make sure to check "Add Python to PATH" during installation.
    echo.
    pause
    goto menu
)

echo Installing required packages...
pip install pywebview pyinstaller

echo.
echo Building executable...
pyinstaller --onefile --windowed --name LibraryOS launcher.py

if errorlevel 1 (
    echo.
    echo ERROR: Build failed!
    pause
    goto menu
)

echo.
echo Creating distribution folder...
if not exist "dist_exe" mkdir dist_exe
if not exist "dist_exe\LibraryOS" mkdir dist_exe\LibraryOS
xcopy /E /I /Y dist dist_exe\LibraryOS\dist
copy dist\LibraryOS.exe dist_exe\LibraryOS\

echo.
echo ========================================
echo ✓ BUILD COMPLETE!
echo ========================================
echo.
echo Your standalone app is in: dist_exe\LibraryOS\
echo.
echo Files:
echo   - LibraryOS.exe (Your application)
echo   - dist\ (Application files)
echo.
echo To distribute:
echo   Zip the entire "LibraryOS" folder and share it!
echo.
pause
goto menu

:show_instructions
echo.
echo ========================================
echo   Build Methods Guide
echo ========================================
echo.
echo Method 1: HTA (HTML Application)
echo   - Easiest, works on all Windows
echo   - Just double-click to run
echo   - Limited camera support
echo.
echo Method 2: Portable Chrome
echo   - Full features including camera
echo   - ~80 MB total size
echo   - Requires Chrome Portable download
echo.
echo Method 3: Python WebView
echo   - True standalone EXE
echo   - Small size (~5 MB)
echo   - Requires Python to build
echo   - Full camera support
echo.
echo Method 4: Neutralinojs
echo   - Very small (~3 MB)
echo   - See STANDALONE-EXE-GUIDE.md
echo.
echo Method 5: C# WebView2
echo   - Most professional
echo   - Requires Visual Studio
echo   - See STANDALONE-EXE-GUIDE.md
echo.
echo Full details in: STANDALONE-EXE-GUIDE.md
echo.
pause
goto menu

:end
echo.
echo Goodbye!
timeout /t 2 /nobreak >nul
exit
