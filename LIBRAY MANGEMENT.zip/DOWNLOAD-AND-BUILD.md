# 🚀 LibraryOS - Download & Build Instructions

## ⚡ Automatic EXE Creation

### **Windows (Easiest)**

1. **Download** this entire project
2. **Open Command Prompt** in the project folder
3. **Run ONE command:**
   ```bash
   npm run build:exe:windows
   ```

That's it! The EXE will be created automatically in `Release/LibraryOS/`

---

## 📥 Step-by-Step Download & Build

### **Method 1: One-Click Build (Recommended)**

```bash
# Step 1: Download/Clone the project
# (Download ZIP from repository or clone)

# Step 2: Navigate to project folder
cd LibraryOS

# Step 3: Run auto-build
npm run build:exe:windows
```

### **Method 2: Manual Build**

```bash
# Step 1: Install dependencies
npm install

# Step 2: Build web app
npm run build

# Step 3: Run interactive builder
BUILD-EXE.bat
```

---

## 🔧 System Requirements

### **For Building:**
- Node.js 16+ (https://nodejs.org)
- Python 3.8+ (https://python.org) - Optional but recommended
- Windows 7 or later

### **For Running (End Users):**
- Windows 7 or later
- **NO Node.js required!**
- **NO Python required!**

---

## 📦 What Gets Created

After building, you'll have:

```
Release/
└── LibraryOS/
    ├── LibraryOS.exe     ← Standalone application
    └── dist/             ← Application files
```

**To Distribute:**
1. Zip the entire `LibraryOS` folder
2. Share the zip file
3. Users extract and double-click `LibraryOS.exe`

---

## 🛠️ Build Methods Available

| Method | Size | Requires | Best For |
|--------|------|----------|----------|
| **PyWebView** | 5 MB | Python | Production (best) |
| **HTA** | 1 MB | Nothing | Quick testing |
| **Portable Chrome** | 80 MB | Download | Full features |
| **Neutralino** | 3 MB | Manual setup | Advanced users |

---

## 🚨 Troubleshooting

### "npm: command not found"
**Solution:** Install Node.js from https://nodejs.org

### "Python not found"
**Solution:** 
- Install Python from https://python.org
- OR use HTA method (no Python needed)
- During install, check "Add Python to PATH"

### "Build failed"
**Solution:**
```bash
# Clean install
npm install
npm run build
BUILD-EXE.bat
# Choose option 2 (HTA) for easiest method
```

### Camera not working in built app
**Solution:** Use Portable Chrome method for full camera support

---

## 📋 Quick Start Guide

### **For Developers:**
```bash
git clone <repository>
cd LibraryOS
npm install
npm run build:exe:windows
```

### **For End Users:**
1. Download `LibraryOS.zip`
2. Extract the folder
3. Double-click `LibraryOS.exe`
4. Done! 🎉

---

## 🔐 Admin Access

**Default Admin Code:** `1234`

Change it in the Admin Panel after first login!

---

## 📖 Features

- ✅ Barcode scanning (books & member cards)
- ✅ Shabbos lending with deposits
- ✅ Member PINs (4-digit)
- ✅ Form processing (upload filled forms)
- ✅ Ban system
- ✅ Activity logging
- ✅ Offline-first (no internet needed)
- ✅ Auto-generated member cards
- ✅ Credit card storage
- ✅ Reports & analytics

---

## 📞 Support

For issues:
1. Check `STANDALONE-EXE-GUIDE.md`
2. Check `QUICK-START.txt`
3. Review error messages
4. Try alternative build methods

---

## 🎯 Next Steps After Building

1. **Test the EXE** on your computer
2. **Test on a clean PC** (without Node.js)
3. **Customize** the admin code
4. **Add your books** and members
5. **Train staff** on the system
6. **Deploy** to your library

---

## 💾 Data Backup

Before distribution:
1. Go to Settings
2. Click "Export All Data"
3. Save the backup file
4. Include backup instructions for users

---

## 🔄 Updates

To update the app:
1. Make changes to the code
2. Run `npm run build:exe:windows` again
3. Replace old EXE with new one
4. User data is preserved (stored in browser LocalStorage)

---

## ✅ Pre-Distribution Checklist

- [ ] EXE builds successfully
- [ ] Tested on clean Windows machine
- [ ] Admin code changed from default
- [ ] Sample data removed (if needed)
- [ ] Forms downloaded and printed
- [ ] Staff trained
- [ ] Backup created
- [ ] Icon customized (optional)
- [ ] README included in zip

---

**Ready to build? Run:**
```bash
npm run build:exe:windows
```

**Your library management system as a standalone Windows application!** 🎉
